/* wcx_manifest.c -- Total Commander WCX shell over manifest_core, round 2.
 *
 * Presents an iOS backup's Manifest.db as a browsable tree. Round 2 moves to TC's
 * wide (Unicode) interface so any-language paths list and extract correctly, uses
 * the \\?\ extended-length form so the deep system paths that exceed the legacy
 * 260-char limit still extract, and stamps each extracted file AND directory with
 * its real Birth/LastModified times from Manifest.db. The ANSI entry points are
 * kept as a fallback for a non-Unicode Total Commander; extraction is always done
 * through the wide file APIs regardless.
 *
 * All Manifest.db logic is in manifest_core.c; this only bridges the WCX API.
 * Build: build_manifest.bat. Undecorated exports via manifest.def.
 */
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include "manifest_core.h"

#ifndef FILE_FLAG_BACKUP_SEMANTICS
#define FILE_FLAG_BACKUP_SEMANTICS 0x02000000
#endif
#ifndef INVALID_FILE_ATTRIBUTES
#define INVALID_FILE_ATTRIBUTES ((DWORD)-1)
#endif

/* ---- the slice of wcxhead.h we use --------------------------------------- */
#define E_SUCCESS          0
#define E_END_ARCHIVE     10
#define E_NO_MEMORY       11
#define E_BAD_ARCHIVE     13
#define E_UNKNOWN_FORMAT  14
#define E_EOPEN           15
#define E_ECREATE         16
#define E_EREAD           18
#define E_EWRITE          19
#define E_EABORTED        21

#define PK_SKIP            0
#define PK_TEST            1
#define PK_EXTRACT         2

#define PK_CAPS_MULTIPLE     4
#define PK_CAPS_BY_CONTENT  64
#define PK_CAPS_SEARCHTEXT 128
#define PK_CAPS_HIDE       256

typedef struct {                                   /* ANSI open data */
    char *ArcName; int OpenMode; int OpenResult;
    char *CmtBuf; int CmtBufSize; int CmtSize; int CmtState;
} tOpenArchiveData;
typedef struct {                                   /* ANSI header */
    char ArcName[260]; char FileName[260];
    int Flags, PackSize, UnpSize, HostOS, FileCRC, FileTime, UnpVer, Method, FileAttr;
    char *CmtBuf; int CmtBufSize; int CmtSize; int CmtState;
} tHeaderData;
typedef struct {                                   /* Unicode open data */
    WCHAR *ArcName; int OpenMode; int OpenResult;
    WCHAR *CmtBuf; int CmtBufSize; int CmtSize; int CmtState;
} tOpenArchiveDataW;
typedef struct {                                   /* Unicode header */
    WCHAR ArcName[1024]; WCHAR FileName[1024];
    int Flags;
    unsigned int PackSize, PackSizeHigh, UnpSize, UnpSizeHigh;
    int HostOS, FileCRC, FileTime, UnpVer, Method, FileAttr;
    WCHAR *CmtBuf; int CmtBufSize; int CmtSize; int CmtState;
    int Reserved[1024];
} tHeaderDataExW;

typedef int (__stdcall *tProcessDataProc)(char *FileName, int Size);
typedef int (__stdcall *tChangeVolProc)(char *ArcName, int Mode);
typedef int (__stdcall *tProcessDataProcW)(WCHAR *FileName, int Size);
typedef int (__stdcall *tChangeVolProcW)(WCHAR *ArcName, int Mode);

typedef struct {
    man_archive      *arc;
    int               cursor;
    tProcessDataProc  procA;
    tProcessDataProcW procW;
} t_handle;

/* ---- string conversions --------------------------------------------------- */
static int  widen(const char *u8, WCHAR *out, int cap){            /* UTF-8 -> UTF-16 */
    int r = MultiByteToWideChar(CP_UTF8, 0, u8, -1, out, cap);
    if(r <= 0){ if(cap > 0) out[0] = 0; return 0; }   /* always leave it terminated */
    return 1;
}
static int  ansi_to_utf8(const char *a, char *out, int cap){       /* ANSI -> UTF-8 */
    WCHAR w[4096];
    if(MultiByteToWideChar(CP_ACP, 0, a, -1, w, 4096) == 0) return 0;
    return WideCharToMultiByte(CP_UTF8, 0, w, -1, out, cap, NULL, NULL) > 0;
}
static void utf8_to_ansi(const char *u8, char *out, int cap){      /* UTF-8 -> ANSI (lossy) */
    WCHAR w[4096];
    out[0]=0;
    if(MultiByteToWideChar(CP_UTF8, 0, u8, -1, w, 4096) == 0) return;
    if(WideCharToMultiByte(CP_ACP, 0, w, -1, out, cap, NULL, NULL) <= 0) out[0]=0;
}
static void wide_to_ansi(const WCHAR *w, char *out, int cap){      /* UTF-16 -> ANSI (lossy) */
    if(WideCharToMultiByte(CP_ACP, 0, w, -1, out, cap, NULL, NULL) <= 0) out[0]=0;
}

/* ---- time ----------------------------------------------------------------- */
static FILETIME unix_to_ft(long long s){
    ULONGLONG ll = ((ULONGLONG)s + 11644473600ULL) * 10000000ULL;
    FILETIME ft; ft.dwLowDateTime=(DWORD)(ll&0xFFFFFFFFULL); ft.dwHighDateTime=(DWORD)(ll>>32);
    return ft;
}
static int unix_to_dos(long long s){
    if(s<=0) return 0;
    FILETIME ft=unix_to_ft(s), lft; WORD d=0,t=0;
    if(FileTimeToLocalFileTime(&ft,&lft) && FileTimeToDosDateTime(&lft,&d,&t))
        return ((int)d<<16)|(int)t;
    return 0;
}

/* ---- wide path helpers ---------------------------------------------------- */
/* Normalise slashes and, for a drive-absolute path, prepend \\?\ so that paths
   longer than MAX_PATH work. Already-extended or UNC paths are left (slash-fixed). */
static void longify(const WCHAR *in, WCHAR *out, int cap){
    int i=0, j=0;
    if(in[0]==L'\\'&&in[1]==L'\\'&&in[2]==L'?'&&in[3]==L'\\'){           /* already \\?\ */
        for(; in[i]&&j<cap-1; i++) out[j++]=(in[i]==L'/')?L'\\':in[i];
        out[j]=0; return;
    }
    if(in[0] && in[1]==L':'){                                           /* X:\... */
        const WCHAR *pfx=L"\\\\?\\";
        while(pfx[j]&&j<cap-1){ out[j]=pfx[j]; j++; }
        for(; in[i]&&j<cap-1; i++) out[j++]=(in[i]==L'/')?L'\\':in[i];
        out[j]=0; return;
    }
    for(; in[i]&&j<cap-1; i++) out[j++]=(in[i]==L'/')?L'\\':in[i];        /* relative/UNC */
    out[j]=0;
}
/* Create every directory along a (already longified) path. include_last also
   creates the final component (for directory members). */
static void ensure_tree_w(const WCHAR *path, int include_last){
    WCHAR tmp[4096]; int n=0; while(path[n] && n<4095){ tmp[n]=path[n]; n++; } tmp[n]=0;
    int start=0;
    if(n>=4 && tmp[0]==L'\\'&&tmp[1]==L'\\'&&tmp[2]==L'?'&&tmp[3]==L'\\') start=4;
    if(n>=start+2 && tmp[start+1]==L':') start+=2;
    if(tmp[start]==L'\\'||tmp[start]==L'/') start++;
    int i;
    for(i=start; tmp[i]; i++){
        if(tmp[i]==L'\\'||tmp[i]==L'/'){ WCHAR c=tmp[i]; tmp[i]=0; CreateDirectoryW(tmp,NULL); tmp[i]=c; }
    }
    if(include_last) CreateDirectoryW(tmp, NULL);
}
/* Stamp creation+modified times on a file or directory (path already longified). */
static void set_times_w(const WCHAR *path, long long ctime, long long mtime, int isdir){
    if(ctime<=0 && mtime<=0) return;
    DWORD flags = isdir ? FILE_FLAG_BACKUP_SEMANTICS : FILE_ATTRIBUTE_NORMAL;
    HANDLE hf = CreateFileW(path, GENERIC_WRITE, FILE_SHARE_READ|FILE_SHARE_WRITE,
                            NULL, OPEN_EXISTING, flags, NULL);
    if(hf == INVALID_HANDLE_VALUE) return;
    FILETIME cft=unix_to_ft(ctime>0?ctime:mtime), mft=unix_to_ft(mtime>0?mtime:ctime);
    SetFileTime(hf, &cft, NULL, &mft);
    CloseHandle(hf);
}
/* Copy the UTF-8 source blob to a (longified) wide destination, making parents. */
static int copy_blob_w(t_handle *h, const char *src_u8, const WCHAR *longdst){
    WCHAR srcw[4096], srclong[4096];
    if(!widen(src_u8, srcw, 4096)) return E_EOPEN;
    longify(srcw, srclong, 4096);
    ensure_tree_w(longdst, 0);
    FILE *in = _wfopen(srclong, L"rb");  if(!in) return E_EOPEN;
    FILE *out = _wfopen(longdst, L"wb"); if(!out){ fclose(in); return E_ECREATE; }
    char ansicb[1024]; int have_a = (h->procA && !h->procW);
    if(have_a) wide_to_ansi(longdst, ansicb, sizeof(ansicb));
    char buf[65536]; size_t n; int rc=E_SUCCESS;
    while((n=fread(buf,1,sizeof(buf),in))>0){
        if(fwrite(buf,1,n,out)!=n){ rc=E_EWRITE; break; }
        if(h->procW){ if(h->procW((WCHAR*)longdst,(int)n)==0){ rc=E_EABORTED; break; } }
        else if(h->procA){ if(h->procA(ansicb,(int)n)==0){ rc=E_EABORTED; break; } }
    }
    if(rc==E_SUCCESS && ferror(in)) rc=E_EREAD;
    fclose(in); fclose(out);
    if(rc!=E_SUCCESS) _wremove(longdst);
    return rc;
}
/* Shared extraction for one entry to a wide destination path. */
static int do_extract(t_handle *h, man_entry *e, const WCHAR *dstw){
    WCHAR longdst[4096]; longify(dstw, longdst, 4096);
    int rc=E_SUCCESS;
    if(e->isdir){
        ensure_tree_w(longdst, 1);
        set_times_w(longdst, e->ctime, e->mtime, 1);
    } else if(!e->src){
        /* symlink or content absent from the backup: nothing to write */
    } else {
        rc = copy_blob_w(h, e->src, longdst);
        if(rc==E_SUCCESS) set_times_w(longdst, e->ctime, e->mtime, 0);
    }
    man_log("EXTRACT %s '%s' rc=%d", e->isdir?"dir":(e->src?"file":"skip"), e->name, rc);
    return rc;
}

/* ======================= Unicode WCX entry points ========================= */

HANDLE __stdcall OpenArchiveW(tOpenArchiveDataW *d){
    if(!d || !d->ArcName){ if(d) d->OpenResult=E_UNKNOWN_FORMAT; return NULL; }
    char u8[4096];
    if(WideCharToMultiByte(CP_UTF8,0,d->ArcName,-1,u8,sizeof(u8),NULL,NULL)<=0){ d->OpenResult=E_BAD_ARCHIVE; return NULL; }
    if(!man_is_manifest(u8)){ d->OpenResult=E_UNKNOWN_FORMAT; return NULL; }
    man_archive *arc=man_open(u8);
    man_log("== OpenArchiveW ==  %s  (%d entries)", u8, arc?arc->count:-1);
    if(!arc){ d->OpenResult=E_BAD_ARCHIVE; return NULL; }
    t_handle *h=(t_handle*)calloc(1,sizeof(t_handle));
    if(!h){ man_close(arc); d->OpenResult=E_NO_MEMORY; return NULL; }
    h->arc=arc; d->OpenResult=E_SUCCESS;
    return (HANDLE)h;
}

int __stdcall ReadHeaderExW(HANDLE hArc, tHeaderDataExW *hd){
    t_handle *h=(t_handle*)hArc;
    if(!h || !hd) return E_BAD_ARCHIVE;
    if(h->cursor >= h->arc->count) return E_END_ARCHIVE;
    man_entry *e=&h->arc->items[h->cursor];
    /* Set only fields TC reads; never memset by sizeof(*hd) -- TC owns the buffer
       and its trailing Reserved[] size is not ours to assume. Writing past CmtState
       (e.g. a too-large struct) corrupts TC's heap and crashes it. */
    hd->ArcName[0]  = 0;
    widen(e->name, hd->FileName, 1024);
    hd->Flags        = 0;
    hd->PackSize     = (unsigned int)((unsigned long long)e->size & 0xFFFFFFFFULL);
    hd->PackSizeHigh = (unsigned int)((unsigned long long)e->size >> 32);
    hd->UnpSize      = hd->PackSize;
    hd->UnpSizeHigh  = hd->PackSizeHigh;
    hd->HostOS       = 0;
    hd->FileCRC      = 0;
    hd->FileTime     = unix_to_dos(e->mtime);
    hd->UnpVer       = 0;
    hd->Method       = 0;
    hd->FileAttr     = e->isdir ? FILE_ATTRIBUTE_DIRECTORY : FILE_ATTRIBUTE_ARCHIVE;
    hd->CmtBuf       = NULL;
    hd->CmtBufSize   = 0;
    hd->CmtSize      = 0;
    hd->CmtState     = 0;
    return E_SUCCESS;
}

int __stdcall ProcessFileW(HANDLE hArc, int Operation, WCHAR *DestPath, WCHAR *DestName){
    t_handle *h=(t_handle*)hArc;
    if(!h) return E_BAD_ARCHIVE;
    if(h->cursor >= h->arc->count) return E_END_ARCHIVE;
    man_entry *e=&h->arc->items[h->cursor];
    int rc=E_SUCCESS;
    if(Operation==PK_EXTRACT){
        WCHAR dst[4096];
        if(DestPath && DestPath[0] && DestName) _snwprintf(dst, 4096, L"%s%s", DestPath, DestName);
        else if(DestName)                       _snwprintf(dst, 4096, L"%s", DestName);
        else { h->cursor++; return E_ECREATE; }
        dst[4095]=0;
        rc=do_extract(h, e, dst);
    }
    h->cursor++;
    return rc;
}

void __stdcall SetChangeVolProcW(HANDLE hArc, tChangeVolProcW p){ (void)hArc; (void)p; }
void __stdcall SetProcessDataProcW(HANDLE hArc, tProcessDataProcW p){
    t_handle *h=(t_handle*)hArc;
    if(h && hArc!=INVALID_HANDLE_VALUE) h->procW=p;
}
BOOL __stdcall CanYouHandleThisFileW(WCHAR *FileName){
    char u8[4096];
    if(!FileName || WideCharToMultiByte(CP_UTF8,0,FileName,-1,u8,sizeof(u8),NULL,NULL)<=0) return FALSE;
    int r = man_is_manifest(u8) ? 1 : 0;
    if(r) man_log("== CanYouHandleThisFileW ==  %s -> YES", u8);
    return r ? TRUE : FALSE;
}

/* ========================= ANSI fallback entry points ===================== */

HANDLE __stdcall OpenArchive(tOpenArchiveData *d){
    if(!d || !d->ArcName){ if(d) d->OpenResult=E_UNKNOWN_FORMAT; return NULL; }
    char u8[4096];
    if(!ansi_to_utf8(d->ArcName,u8,sizeof(u8)) || !man_is_manifest(u8)){ d->OpenResult=E_UNKNOWN_FORMAT; return NULL; }
    man_archive *arc=man_open(u8);
    if(!arc){ d->OpenResult=E_BAD_ARCHIVE; return NULL; }
    t_handle *h=(t_handle*)calloc(1,sizeof(t_handle));
    if(!h){ man_close(arc); d->OpenResult=E_NO_MEMORY; return NULL; }
    h->arc=arc; d->OpenResult=E_SUCCESS;
    return (HANDLE)h;
}
int __stdcall ReadHeader(HANDLE hArc, tHeaderData *hd){
    t_handle *h=(t_handle*)hArc;
    if(!h || !hd) return E_BAD_ARCHIVE;
    if(h->cursor >= h->arc->count) return E_END_ARCHIVE;
    man_entry *e=&h->arc->items[h->cursor];
    memset(hd,0,sizeof(*hd));
    utf8_to_ansi(e->name, hd->FileName, sizeof(hd->FileName));  /* lossy on non-ACP names */
    hd->PackSize = (int)e->size; hd->UnpSize = (int)e->size;
    hd->FileTime = unix_to_dos(e->mtime);
    hd->FileAttr = e->isdir ? FILE_ATTRIBUTE_DIRECTORY : FILE_ATTRIBUTE_ARCHIVE;
    return E_SUCCESS;
}
int __stdcall ProcessFile(HANDLE hArc, int Operation, char *DestPath, char *DestName){
    t_handle *h=(t_handle*)hArc;
    if(!h) return E_BAD_ARCHIVE;
    if(h->cursor >= h->arc->count) return E_END_ARCHIVE;
    man_entry *e=&h->arc->items[h->cursor];
    int rc=E_SUCCESS;
    if(Operation==PK_EXTRACT){
        char dsta[4096]; WCHAR dstw[4096];
        if(DestPath && *DestPath && DestName) snprintf(dsta,sizeof(dsta),"%s%s",DestPath,DestName);
        else if(DestName)                     snprintf(dsta,sizeof(dsta),"%s",DestName);
        else { h->cursor++; return E_ECREATE; }
        dsta[sizeof(dsta)-1]=0;
        if(MultiByteToWideChar(CP_ACP,0,dsta,-1,dstw,4096)==0){ h->cursor++; return E_ECREATE; }
        rc=do_extract(h, e, dstw);
    }
    h->cursor++;
    return rc;
}
void __stdcall SetChangeVolProc(HANDLE hArc, tChangeVolProc p){ (void)hArc; (void)p; }
void __stdcall SetProcessDataProc(HANDLE hArc, tProcessDataProc p){
    t_handle *h=(t_handle*)hArc;
    if(h && hArc!=INVALID_HANDLE_VALUE) h->procA=p;
}
BOOL __stdcall CanYouHandleThisFile(char *FileName){
    char u8[4096];
    if(!FileName || !ansi_to_utf8(FileName,u8,sizeof(u8))) return FALSE;
    return man_is_manifest(u8) ? TRUE : FALSE;
}

/* ============================== shared ==================================== */
int __stdcall CloseArchive(HANDLE hArc){
    t_handle *h=(t_handle*)hArc;
    man_log("CloseArchive");
    if(!h) return E_SUCCESS;
    if(h->arc) man_close(h->arc);
    free(h);
    return E_SUCCESS;
}
int __stdcall GetPackerCaps(void){
    return PK_CAPS_BY_CONTENT | PK_CAPS_MULTIPLE | PK_CAPS_SEARCHTEXT | PK_CAPS_HIDE;  /* = 452 */
}
