@echo off
rem ============================================================================
rem  Build ManifestDB.wcx for Total Commander (32-bit, runs on Windows XP).
rem
rem  >>> EDIT THE NEXT LINE ONLY <<<  Point it at the folder where you extracted
rem      mingw -- the one that contains gcc.exe (its name ends in \bin).
set "MINGW_BIN=C:\mingw32\bin"
rem ============================================================================
rem
rem  Put this file in the same folder as the sources:
rem      wcx_manifest.c  manifest_core.c  manifest_core.h
rem      manifest.def    sqlite3.c        sqlite3.h
rem  (sqlite3.c / sqlite3.h are the SQLite amalgamation -- the very same pair you
rem   already used for notestore.wcx; just copy them in here.)
rem  Then just double-click it.
rem ============================================================================
cd /d "%~dp0"
path %MINGW_BIN%;%PATH%

rem Use the target-prefixed compiler if present, otherwise plain gcc.
set "CC=gcc"
i686-w64-mingw32-gcc --version >nul 2>&1 && set "CC=i686-w64-mingw32-gcc"

echo Compiler : %CC%
echo Bin path : %MINGW_BIN%
echo.
echo Building ManifestDB.wcx ...
echo.

rem  -I.  =  also look in THIS folder for headers (finds sqlite3.h, manifest_core.h)
%CC% -std=gnu99 -O2 -I. -shared -o ManifestDB.wcx ^
    wcx_manifest.c manifest_core.c sqlite3.c manifest.def ^
    -static-libgcc -lkernel32

if errorlevel 1 (
    echo.
    echo *** BUILD FAILED -- read the messages above. ***
    echo     "'gcc' is not recognized"  -^> the MINGW_BIN line above is wrong,
    echo                                   or the .7z was not fully extracted.
    echo     sqlite3.h not found        -^> sqlite3.c / sqlite3.h are not in
    echo                                   this folder yet.
) else (
    echo.
    echo *** BUILD OK -- ManifestDB.wcx was created in this folder. ***
)
echo.
pause
