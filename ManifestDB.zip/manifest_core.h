/* manifest_core.h -- parser/resolver core for an iOS backup Manifest.db.
 *
 * An iOS backup stores every file's content under a name that is the SHA-1 of its
 * "<domain>-<relativePath>" identity (NOT a content checksum), at
 * <backup>/<name[:2]>/<name>, and Manifest.db's Files table maps each name to its
 * domain + relativePath + flags + a per-file metadata blob. This core turns that
 * table into a flat list of entries the Total Commander WCX shell presents as a
 * browsable tree.
 *
 * Names are kept as UTF-8; the shell converts to UTF-16 for Total Commander's wide
 * API so any-language paths list and extract correctly. Timestamps come from each
 * row's NSKeyedArchiver metadata blob. Deterministic and platform-neutral;
 * validated on Linux against reconstruct_backup.py and Python's plistlib.
 */
#ifndef MANIFEST_CORE_H
#define MANIFEST_CORE_H

typedef struct {
    char     *name;   /* UTF-8 path, backslash-separated and sanitised, e.g.
                         "HomeDomain\Library\Preferences\com.apple.x.plist" */
    char     *src;    /* on-disk blob to copy bytes from; NULL for directories,
                         symlinks, and files whose content is absent from the backup */
    long long size;   /* logical size in bytes (from metadata; 0 for directories)  */
    long long ctime;  /* created  (Birth)        -- Unix seconds, UTC              */
    long long mtime;  /* modified (LastModified)  -- Unix seconds, UTC              */
    int       isdir;  /* 1 = directory entry (FILE_ATTRIBUTE_DIRECTORY)            */
} man_entry;

typedef struct {
    man_entry *items;
    int        count;
} man_archive;

/* 1 if the file is an iOS backup Manifest.db (SQLite + a Files table with the
   expected columns), 0 otherwise. 'path' is UTF-8. -> WCX CanYouHandleThisFile(W) */
int          man_is_manifest(const char *path);

/* Parse Manifest.db (UTF-8 path) and build the entry list. The backup root is the
   directory containing the Manifest.db. Returns NULL on open failure. -> OpenArchive(W) */
man_archive* man_open(const char *path);

/* Free everything returned by man_open. -> WCX CloseArchive */
void         man_close(man_archive *a);

/* Debug log line, appended to C:\manifestdb_wcx.log (temporary; for bring-up). */
void         man_log(const char *fmt, ...);

#endif /* MANIFEST_CORE_H */
