@echo off
REM ---- Apple AFC.wfx : 32-bit Total Commander WFX plugin ----
REM -static-libgcc bakes in the GCC runtime so the plugin needs no libgcc_s_dw2-1.dll
C:\mingw32\bin\windres.exe afc.rc -O coff -o afc_rc.o
C:\mingw32\bin\gcc.exe -std=gnu99 -O2 -shared -static-libgcc -Wno-unused-function -o "Apple AFC.wfx" afc_wfx.c afc_rc.o afc_wfx.def -lws2_32 -lcrypt32 -ladvapi32 -lsecur32 -lgdi32 -Wl,--kill-at
echo done.
