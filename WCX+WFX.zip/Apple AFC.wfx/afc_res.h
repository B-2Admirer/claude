#ifndef AFC_RES_H
#define AFC_RES_H

/* Properties dialog (Step 4). IDOK comes from windows.h. */
#define IDD_PROPS      200
#define IDC_PROP_EDIT  201
#define IDC_PROP_COPY  202

#endif /* AFC_RES_H */
