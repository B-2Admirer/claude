/* fsplugin.h -- Total Commander WFX (file system plugin) interface.
   Re-declared from the published TC plugin ABI (stable contract; not Apple/TC source).
   Only the pieces this plugin needs are declared here. All exported Fs* functions are
   __stdcall (WINAPI); the .def + -Wl,--kill-at give them undecorated export names. */
#ifndef FSPLUGIN_H
#define FSPLUGIN_H

#include <windows.h>

/* ---- FsGetFile / FsPutFile result codes ---- */
#define FS_FILE_OK                  0
#define FS_FILE_EXISTS              1
#define FS_FILE_NOTFOUND            2
#define FS_FILE_READERROR           3
#define FS_FILE_WRITEERROR          4
#define FS_FILE_USERABORT           5
#define FS_FILE_NOTSUPPORTED        6
#define FS_FILE_EXISTSRESUMEALLOWED 7

/* ---- copy flags ---- */
#define FS_COPYFLAGS_OVERWRITE             1
#define FS_COPYFLAGS_RESUME                2
#define FS_COPYFLAGS_MOVE                  4
#define FS_COPYFLAGS_EXISTS_SAMECASE       8
#define FS_COPYFLAGS_EXISTS_DIFFERENTCASE 16

/* ---- FsExecuteFile result codes ---- */
#define FS_EXEC_OK       0
#define FS_EXEC_ERROR    1
#define FS_EXEC_YOURSELF (-1)
#define FS_EXEC_SYMLINK  (-2)

/* ---- FsExtractCustomIcon flags + result codes ---- */
#define FS_ICONFLAG_SMALL          1
#define FS_ICONFLAG_BACKGROUND     2
#define FS_ICON_USEDEFAULT         0
#define FS_ICON_EXTRACTED          1
#define FS_ICON_EXTRACTED_DESTROY  2
#define FS_ICON_DELAYED            3

/* ---- FsStatusInfo start/end ---- */
#define FS_STATUS_START 0
#define FS_STATUS_END   1
/* ---- FsStatusInfo operations ---- */
#define FS_STATUS_OP_LIST           1
#define FS_STATUS_OP_GET_SINGLE     2
#define FS_STATUS_OP_GET_MULTI      3
#define FS_STATUS_OP_PUT_SINGLE     4
#define FS_STATUS_OP_PUT_MULTI      5
#define FS_STATUS_OP_RENMOV_SINGLE  6
#define FS_STATUS_OP_RENMOV_MULTI   7
#define FS_STATUS_OP_DELETE         8
#define FS_STATUS_OP_ATTRIB         9
#define FS_STATUS_OP_MKDIR         10
#define FS_STATUS_OP_EXEC          11
#define FS_STATUS_OP_CALCSIZE      12

/* ---- background-transfer support flags (FsGetBackgroundFlags) ---- */
#define BG_DOWNLOAD 1
#define BG_UPLOAD   2
#define BG_ASK_USER 4

/* ---- Log message types (tLogProc MsgType) ---- */
#define MSGTYPE_CONNECT          1
#define MSGTYPE_DISCONNECT       2
#define MSGTYPE_DETAILS          3
#define MSGTYPE_TRANSFERCOMPLETE 4
#define MSGTYPE_CONNECTCOMPLETE  5
#define MSGTYPE_IMPORTANTERROR   6
#define MSGTYPE_OPERATIONCOMPLETE 7

/* ---- Request types (tRequestProc RequestType) ---- */
#define RT_Other         0
#define RT_UserName      1
#define RT_Password      2
#define RT_Account       3
#define RT_UserNameFirewall 4
#define RT_PasswordFirewall 5
#define RT_TargetDir     6
#define RT_URL           7
#define RT_MsgOK         8
#define RT_MsgYesNo      9
#define RT_MsgOKCancel  10

/* ---- callback prototypes passed to FsInit / FsInitW ---- */
typedef int  (__stdcall *tProgressProc) (int PluginNr,char* SourceName,char* TargetName,int PercentDone);
typedef void (__stdcall *tLogProc)      (int PluginNr,int MsgType,char* LogString);
typedef BOOL (__stdcall *tRequestProc)  (int PluginNr,int RequestType,char* CustomTitle,char* CustomText,char* ReturnedText,int maxlen);

typedef int  (__stdcall *tProgressProcW)(int PluginNr,WCHAR* SourceName,WCHAR* TargetName,int PercentDone);
typedef void (__stdcall *tLogProcW)     (int PluginNr,int MsgType,WCHAR* LogString);
typedef BOOL (__stdcall *tRequestProcW) (int PluginNr,int RequestType,WCHAR* CustomTitle,WCHAR* CustomText,WCHAR* ReturnedText,int maxlen);

/* ---- structs ---- */
typedef struct {
    int   size;
    DWORD PluginInterfaceVersionLow;
    DWORD PluginInterfaceVersionHi;
    char  DefaultIniName[MAX_PATH];
} FsDefaultParamStruct;

typedef struct {
    DWORD    SizeLow;
    DWORD    SizeHigh;
    FILETIME LastWriteTime;
    DWORD    Attr;
} RemoteInfoStruct;

#endif /* FSPLUGIN_H */
