/* afc_wfx.c -- "Apple AFC", a Total Commander file-system (WFX) plugin.
 *
 * STEP 1 (rev 2): virtual root + XP-loadable icon + live diagnostics.
 *   - The plugin root "\" is a VIRTUAL level listing the AFC services as folders
 *     ("Media" = com.apple.afc today; "Full Filesystem" = com.apple.afc2 slots in later).
 *   - The persistent session is established lazily on first entry into a service folder
 *     and held for the whole TC session; FsDisconnect tears it down.
 *   - Connection + icon steps emit OutputDebugString lines (watch them in DebugView).
 * Unity build: includes the hardware-validated AFC core (afc_probe.c, AFC_CORE_LIB) and
 * wraps its proven primitives, so the probe and the plugin share one source of truth.
 */
#define AFC_CORE_LIB
#include "afc_probe.c"     /* winsock2.h/windows.h/schannel + the AFC core */
#include "fsplugin.h"
#include "afc_res.h"     /* dialog + control IDs (shared with afc.rc) */

#define IDI_AFC 101
#define AMDS_HOST "127.0.0.1"
#define AMDS_PORT 27015

/* ----------------------------- plugin-wide state ----------------------------- */
static HINSTANCE      g_hinst     = NULL;
static int            g_plugin_nr = 0;
static tProgressProcW g_progressW = NULL;
static tLogProcW      g_logW      = NULL;
static tRequestProcW  g_requestW  = NULL;
static int            g_wsa       = 0;
static char           g_ini_ansi[MAX_PATH] = {0};   /* DefaultIniName from FsSetDefaultParams (ANSI) */

/* directory-time replication state (helpers defined further down) */
static char         **g_cp_dirs  = NULL;
static int            g_cp_ndirs=0, g_cp_capdirs=0, g_cp_depth=0, g_cp_anchor=0, g_cp_dir=0;
static char           g_cp_lpre[AFC_PATHMAX];   /* local  copy-root parent, utf8, '/'-separated */
static char           g_cp_rpre[AFC_PATHMAX];   /* device copy-root parent (afc)                */
static void           cp_add_dir(const char *afc);

typedef struct {
    int                connected;
    sock_t             sock;
    uint64_t           pkt;
    char               udid[128];
    char               model[64];
    char               afc_version[160];
    char               conn_type[24];
    char               ios_version[32];     /* lockdown ProductVersion (captured over TLS) */
    char               tls_info[160];       /* negotiated protocol + cipher                */
    unsigned long long fs_total, fs_free, fs_block;
    char               last_error[512];
} afc_session_t;

static afc_session_t g_s;

/* live diagnostics -> view with DebugView (OutputDebugString). Free if no viewer attached. */
#define DBG(...) do{ char _dbg[400]; snprintf(_dbg,sizeof(_dbg),__VA_ARGS__); OutputDebugStringA(_dbg); }while(0)

/* ------------------------------- small helpers ------------------------------- */
static void wlog(int type, const char *utf8){
    WCHAR w[600];
    if(!g_logW) return;
    MultiByteToWideChar(CP_UTF8,0,utf8,-1,w,600);
    g_logW(g_plugin_nr,type,w);
}

/* The com.apple.afc service is jailed to /var/mobile/Media on the device. We present its
 * contents at exactly that path, so the layout matches what com.apple.afc2 (the full
 * filesystem) would show; the directories above the jail are SYNTHESISED, because afc itself
 * cannot list them. Adding com.apple.afc2 later just makes "\" and those ancestors real
 * instead of synthetic, and the Media subtree lines up unchanged underneath.
 *
 *   "\"  "\var"  "\var\mobile"     -> synthetic ancestors (each lists its single next child)
 *   "\var\mobile\Media"            -> com.apple.afc, AFC path "/"
 *   "\var\mobile\Media\DCIM\1.."   -> com.apple.afc, AFC path "/DCIM/1.."
 */
static const char *MOUNT[] = { "var", "mobile", "Media" };
#define MOUNT_DEPTH 3
#define VF_MOUNT L"\\var\\mobile\\Media"

/* Classify a TC path against the mount. Returns:
 *   0  -> synthetic ancestor of the jail; *synth = the single child directory to list
 *   1  -> at/below the jail; *afc = the (forward-slash) AFC path
 *  -1  -> off the mount tree (afc cannot serve it; afc2 will, later) */
static int tc_classify(const WCHAR *tc, char *synth, int sc, char *afc, int ac){
    char u8[AFC_PATHMAX], tmp[AFC_PATHMAX], *p, *s, *tok, *comps[64]; int nc=0, i, m, pos;
    if(tc[0]==L'\\' && tc[1]==0){ u8[0]=0; }                          /* root -> no components */
    else { WideCharToMultiByte(CP_UTF8,0,tc,-1,u8,sizeof(u8),NULL,NULL); for(p=u8;*p;p++) if(*p=='\\')*p='/'; }
    snprintf(tmp,sizeof(tmp),"%s",u8);
    s=tmp; while(*s=='/') s++;
    for(tok=strtok(s,"/"); tok && nc<64; tok=strtok(NULL,"/")) comps[nc++]=tok;
    m = nc<MOUNT_DEPTH ? nc : MOUNT_DEPTH;
    for(i=0;i<m;i++) if(strcmp(comps[i],MOUNT[i])!=0) return -1;       /* diverges before the jail */
    if(nc<MOUNT_DEPTH){ snprintf(synth,sc,"%s",MOUNT[nc]); return 0; } /* ancestor: next synthetic child */
    if(nc==MOUNT_DEPTH){ afc[0]='/'; afc[1]=0; return 1; }             /* the jail root itself */
    pos=0; afc[pos++]='/';                                            /* below the jail: strip the prefix */
    for(i=MOUNT_DEPTH;i<nc;i++){ int l=(int)strlen(comps[i]); if(pos+l+1>=ac) break; if(i>MOUNT_DEPTH) afc[pos++]='/'; memcpy(afc+pos,comps[i],l); pos+=l; }
    afc[pos]=0; return 1;
}
static int path_is_root (const WCHAR *p){ return p && p[0]==L'\\' && (p[1]==0 || (p[1]==L'\\'&&p[2]==0)); }
static int path_is_mount(const WCHAR *p){ return p && wcscmp(p,VF_MOUNT)==0; }

/* iOS stat times are nanoseconds since the Unix epoch; FILETIME is 100ns since 1601. */
static void ns_to_filetime(unsigned long long ns, FILETIME *ft){
    unsigned long long t = ns/100ULL + 116444736000000000ULL;
    ft->dwLowDateTime  = (DWORD)(t & 0xFFFFFFFFULL);
    ft->dwHighDateTime = (DWORD)(t >> 32);
}

static void ensure_wsa(void){
    if(!g_wsa){ WSADATA w; if(WSAStartup(MAKEWORD(2,2),&w)==0) g_wsa=1; }
}

static int afc_query_devinfo(void){
    uint64_t op=0; unsigned char *pay=NULL; int pl=0; char v[64];
    if(afc_send(g_s.sock,AFC_OP_GET_DEVINFO,NULL,0,g_s.pkt++)!=0) return 1;
    if(afc_recv(g_s.sock,&op,&pay,&pl)!=0) return 1;
    if(op!=AFC_OP_DATA){ free(pay); return 1; }
    if(afc_kv_lookup(pay,pl,"Model",v,sizeof(v))==0)        snprintf(g_s.model,sizeof(g_s.model),"%s",v);
    if(afc_kv_lookup(pay,pl,"FSTotalBytes",v,sizeof(v))==0) g_s.fs_total=strtoull(v,NULL,10);
    if(afc_kv_lookup(pay,pl,"FSFreeBytes",v,sizeof(v))==0)  g_s.fs_free =strtoull(v,NULL,10);
    if(afc_kv_lookup(pay,pl,"FSBlockSize",v,sizeof(v))==0)  g_s.fs_block=strtoull(v,NULL,10);
    free(pay); return 0;
}
static void afc_query_coninfo(void){
    uint64_t op=0; unsigned char *pay=NULL; int pl=0; char v[160];
    if(afc_send(g_s.sock,AFC_OP_GET_CON_INFO,NULL,0,g_s.pkt++)!=0) return;
    if(afc_recv(g_s.sock,&op,&pay,&pl)!=0) return;
    if(op==AFC_OP_DATA && afc_kv_lookup(pay,pl,"Version",v,sizeof(v))==0){
        size_t L;
        snprintf(g_s.afc_version,sizeof(g_s.afc_version),"%s",v);
        L=strlen(g_s.afc_version);
        while(L>0 && (unsigned char)g_s.afc_version[L-1]<=' ') g_s.afc_version[--L]=0;  /* device appends a newline */
    }
    free(pay);
}

/* lockdown GetValue request (over the TLS session) */
static void build_getvalue(char *o,int c,const char *key){
    snprintf(o,c, XML_HEAD "<dict>"
        "<key>Label</key><string>AFCProbe</string>"
        "<key>Request</key><string>GetValue</string>"
        "<key>Key</key><string>%s</string>"
        "</dict>\n" XML_TAIL, key);
}
static const char *tls_proto_name(unsigned long p){
    switch(p){
        case 0x0020: case 0x0010: return "SSL 3.0";
        case 0x0080: case 0x0040: return "TLS 1.0";
        case 0x0200: case 0x0100: return "TLS 1.1";
        case 0x0800: case 0x0400: return "TLS 1.2";
        case 0x2000: case 0x1000: return "TLS 1.3";
        default:                  return "TLS";
    }
}
static const char *tls_cipher_name(unsigned int a){
    switch(a){
        case 0x6610: return "AES-256";
        case 0x660E: return "AES-128";
        case 0x6611: return "AES";
        case 0x6603: return "3DES";
        case 0x6801: return "RC4";
        case 0x6601: return "DES";
        default:     return "(cipher)";
    }
}
/* Both run while the lockdown TLS session is live; best-effort, never fail the connect. */
static void capture_tls_info(CtxtHandle *ctx){
    SecPkgContext_ConnectionInfo ci;
    g_s.tls_info[0]=0;
    if(QueryContextAttributesA(ctx,SECPKG_ATTR_CONNECTION_INFO,&ci)==SEC_E_OK){
        snprintf(g_s.tls_info,sizeof(g_s.tls_info),"%s, %s (%lu-bit), key exchange %lu-bit",
            tls_proto_name((unsigned long)ci.dwProtocol), tls_cipher_name((unsigned int)ci.aiCipher),
            (unsigned long)ci.dwCipherStrength,(unsigned long)ci.dwExchStrength);
        DBG("[AppleAFC] TLS negotiated: %s", g_s.tls_info);
    }
}
static void capture_ios_version(CtxtHandle *ctx,sock_t s){
    char req[512]; char *resp; char val[64];
    g_s.ios_version[0]=0;
    build_getvalue(req,sizeof(req),"ProductVersion");
    if(lockdown_send_tls(ctx,s,req)!=0) return;
    resp=lockdown_recv_tls(ctx,s); if(!resp) return;
    if(plist_str_after(resp,"Value",val,sizeof(val))) snprintf(g_s.ios_version,sizeof(g_s.ios_version),"%s",val);
    free(resp);
    DBG("[AppleAFC] iOS ProductVersion=%s", g_s.ios_version[0]?g_s.ios_version:"(unknown)");
}

/* Establish usbmux->lockdown->TLS->StartService->AFC and hold the AFC socket.
 * Mirrors the probe's proven sequence; on failure leaves a human g_s.last_error. */
static int afc_connect_session(void){
    char xml[2048], udid[128]={0}, hostid[128]={0}, buid[128]={0};
    long device_id=-1, number=-1; uint32_t msg=0,tag=0,plen=0; unsigned char *resp=NULL;
    static unsigned char rec[65536]; int reclen=0; static char b64[65536];
    sock_t s;
    char *le = g_s.last_error; size_t lec = sizeof(g_s.last_error);

    le[0]=0; g_s.pkt=0;
    ensure_wsa();
    DBG("[AppleAFC] connect: contacting AMDS %s:%d", AMDS_HOST, AMDS_PORT);

    /* 1. ListDevices */
    s=tcp_connect(AMDS_HOST,AMDS_PORT);
    if(s==INVALID_SOCKET){ snprintf(le,lec,"Cannot reach Apple Mobile Device Service on %s:%d -- is it installed and running?",AMDS_HOST,AMDS_PORT); return 1; }
    build_listdevices(xml,sizeof(xml));
    if(usbmux_send(s,1,xml)<0){ CLOSESOCK(s); snprintf(le,lec,"usbmux ListDevices send failed."); return 1; }
    resp=usbmux_recv(s,&msg,&tag,&plen); CLOSESOCK(s);
    if(!resp){ snprintf(le,lec,"No reply to usbmux ListDevices."); return 1; }
    if(!plist_str_after((char*)resp,"SerialNumber",udid,sizeof(udid))){
        free(resp); snprintf(le,lec,"No device found -- check the cable and that the iPhone is unlocked and trusted."); return 1;
    }
    device_id=plist_int_after((char*)resp,"DeviceID"); free(resp);
    if(device_id<0){ snprintf(le,lec,"Could not read DeviceID from usbmux."); return 1; }
    snprintf(g_s.udid,sizeof(g_s.udid),"%s",udid);
    DBG("[AppleAFC] connect: device DeviceID=%ld UDID=%s", device_id, udid);

    /* 2. pairing record (usbmux, else disk) */
    s=tcp_connect(AMDS_HOST,AMDS_PORT);
    if(s==INVALID_SOCKET){ snprintf(le,lec,"AMDS unreachable for ReadPairRecord."); return 1; }
    build_readpairrecord(xml,sizeof(xml),udid);
    if(usbmux_send(s,2,xml)<0){ CLOSESOCK(s); snprintf(le,lec,"ReadPairRecord send failed."); return 1; }
    resp=usbmux_recv(s,&msg,&tag,&plen); CLOSESOCK(s);
    if(resp && plist_data_after((char*)resp,"PairRecordData",b64,sizeof(b64))){
        free(resp); reclen=b64decode(b64,rec,sizeof(rec));
    } else {
        if(resp) free(resp);
        reclen=read_pairrecord_from_disk(udid,rec,sizeof(rec));
    }
    if(reclen<=0){ snprintf(le,lec,"Pairing record not found -- connect via USB, unlock the phone and tap Trust, then retry."); return 1; }
    if(!rec_get_str(rec,reclen,"HostID",hostid,sizeof(hostid))){ snprintf(le,lec,"Pairing record is missing HostID."); return 1; }
    rec_get_str(rec,reclen,"SystemBUID",buid,sizeof(buid));
    DBG("[AppleAFC] connect: pairing OK (%d bytes)", reclen);

    /* 3. tunnel to lockdown, QueryType, StartSession */
    s=tcp_connect(AMDS_HOST,AMDS_PORT);
    if(s==INVALID_SOCKET){ snprintf(le,lec,"AMDS unreachable for the lockdown connection."); return 1; }
    build_connect(xml,sizeof(xml),device_id,swap16(LOCKDOWN_PORT));
    if(usbmux_send(s,3,xml)<0){ CLOSESOCK(s); snprintf(le,lec,"lockdown Connect send failed."); return 1; }
    resp=usbmux_recv(s,&msg,&tag,&plen); if(!resp){ CLOSESOCK(s); snprintf(le,lec,"No reply to lockdown Connect."); return 1; }
    number=(msg==MESSAGE_PLIST)?plist_int_after((char*)resp,"Number"):((plen>=4)?(long)get_le32(resp):-1); free(resp);
    if(number!=0){ CLOSESOCK(s); snprintf(le,lec,"Could not tunnel to lockdownd (%s).",result_name(number)); return 1; }
    DBG("[AppleAFC] connect: lockdown tunnel up");

    build_querytype(xml,sizeof(xml));
    if(lockdown_send(s,xml)<0){ CLOSESOCK(s); snprintf(le,lec,"lockdown QueryType send failed."); return 1; }
    resp=lockdown_recv(s); if(resp) free(resp);

    build_startsession(xml,sizeof(xml),hostid,buid);
    if(lockdown_send(s,xml)<0){ CLOSESOCK(s); snprintf(le,lec,"StartSession send failed."); return 1; }
    resp=lockdown_recv(s); if(!resp){ CLOSESOCK(s); snprintf(le,lec,"No reply to StartSession."); return 1; }
    { char err[128]={0};
      if(plist_str_after((char*)resp,"Error",err,sizeof(err))){
          free(resp); CLOSESOCK(s);
          snprintf(le,lec,"lockdown StartSession rejected: %s. The pairing may be stale -- re-trust the device.",err);
          return 1;
      } }
    { int sess_ssl=plist_bool_after((char*)resp,"EnableSessionSSL"); free(resp);
      if(sess_ssl!=1){ CLOSESOCK(s); snprintf(le,lec,"Device did not request an SSL session (unexpected for iOS 18.4)."); return 1; } }
    DBG("[AppleAFC] connect: StartSession OK (SSL required)");

    /* 4./5./6. SChannel handshake, StartService over the tunnel, tear tunnel down */
    { CredHandle cred; PCCERT_CONTEXT cert=NULL; CtxtHandle ctx; int svc_port=-1, needssl=0, r;
      if(schannel_build_client_cred(rec,reclen,&cred,&cert,1)!=0){ CLOSESOCK(s); snprintf(le,lec,"Could not build the TLS credential from the pairing record."); return 1; }
      if(schannel_handshake(s,&cred,&ctx)!=0){
          FreeCredentialsHandle(&cred); if(cert) CertFreeCertificateContext(cert); cred_delete_container(); CLOSESOCK(s);
          snprintf(le,lec,"TLS handshake with lockdownd failed."); return 1;
      }
      DBG("[AppleAFC] connect: TLS handshake OK");
      if(tls_init_sizes(&ctx)!=0){
          DeleteSecurityContext(&ctx); FreeCredentialsHandle(&cred); if(cert) CertFreeCertificateContext(cert); cred_delete_container(); CLOSESOCK(s);
          snprintf(le,lec,"TLS stream sizes unavailable."); return 1;
      }
      capture_tls_info(&ctx);                                   /* device-properties enrichment, best-effort */
      capture_ios_version(&ctx,s);
      r=tunnel_startservice(&ctx,s,"com.apple.afc2",&svc_port,&needssl);
      if(r==1) r=tunnel_startservice(&ctx,s,"com.apple.afc",&svc_port,&needssl);
      DeleteSecurityContext(&ctx); FreeCredentialsHandle(&cred); if(cert) CertFreeCertificateContext(cert); cred_delete_container(); CLOSESOCK(s);
      if(r!=0 || svc_port<0){ snprintf(le,lec,"StartService(com.apple.afc) did not return a usable port."); return 1; }
      if(needssl){ snprintf(le,lec,"The AFC service asked for its own SSL handshake (afc2/jailbreak path not implemented)."); return 1; }
      DBG("[AppleAFC] connect: AFC service port=%d ssl=%d", svc_port, needssl);

      /* 7. plaintext AFC connection on its own usbmux Connect */
      s=tcp_connect(AMDS_HOST,AMDS_PORT);
      if(s==INVALID_SOCKET){ snprintf(le,lec,"AMDS unreachable for the AFC connection."); return 1; }
      build_connect(xml,sizeof(xml),device_id,swap16((uint16_t)svc_port));
      if(usbmux_send(s,4,xml)<0){ CLOSESOCK(s); snprintf(le,lec,"AFC Connect send failed."); return 1; }
      resp=usbmux_recv(s,&msg,&tag,&plen); if(!resp){ CLOSESOCK(s); snprintf(le,lec,"No reply to AFC Connect."); return 1; }
      number=(msg==MESSAGE_PLIST)?plist_int_after((char*)resp,"Number"):((plen>=4)?(long)get_le32(resp):-1); free(resp);
      if(number!=0){ CLOSESOCK(s); snprintf(le,lec,"Could not connect to the AFC service (%s).",result_name(number)); return 1; }
    }

    g_s.sock=s; g_s.connected=1;
    snprintf(g_s.conn_type,sizeof(g_s.conn_type),"USB");
    DBG("[AppleAFC] connect: AFC socket open");
    afc_query_devinfo();
    afc_query_coninfo();
    DBG("[AppleAFC] connect: OK model=%s afc=\"%s\" total=%llu free=%llu",
        g_s.model, g_s.afc_version, (unsigned long long)g_s.fs_total, (unsigned long long)g_s.fs_free);
    return 0;
}

static void afc_disconnect_session(void){
    if(g_s.connected){ DBG("[AppleAFC] disconnect"); CLOSESOCK(g_s.sock); g_s.connected=0; }
}

/* READ_DIR -> malloc'd array of utf-8 names (caller frees). Skips . and .. */
static int afc_read_dir_names(const char *path, char ***names_out, int *count_out){
    uint64_t op=0; unsigned char *pay=NULL; int pl=0, i=0, cap=16, n=0; char **arr;
    if(afc_send(g_s.sock,AFC_OP_READ_DIR,(const unsigned char*)path,(int)strlen(path)+1,g_s.pkt++)!=0) return 1;
    if(afc_recv(g_s.sock,&op,&pay,&pl)!=0) return 1;
    if(op!=AFC_OP_DATA){ free(pay); return 1; }
    arr=(char**)malloc((size_t)cap*sizeof(char*));
    while(i<pl){
        const char *nm=(const char*)pay+i; int len=(int)strlen(nm);
        if(len==0) break;
        if(strcmp(nm,".")!=0 && strcmp(nm,"..")!=0){
            if(n>=cap){ cap*=2; arr=(char**)realloc(arr,(size_t)cap*sizeof(char*)); }
            arr[n]=(char*)malloc((size_t)len+1); memcpy(arr[n],nm,(size_t)len+1); n++;
        }
        i+=len+1;
    }
    free(pay);
    *names_out=arr; *count_out=n; return 0;
}

/* device-side SHA-1 of a file (GET_FILE_HASH 0x1D -> 20-byte DATA). 0 on success. */
#define AFC_OP_GET_FILE_HASH 0x1DULL
static int afc_file_sha1(const char *afcpath, unsigned char out[20]){
    uint64_t op=0; unsigned char *pay=NULL; int pl=0;
    if(afc_send(g_s.sock,AFC_OP_GET_FILE_HASH,(const unsigned char*)afcpath,(int)strlen(afcpath)+1,g_s.pkt++)!=0) return -1;
    if(afc_recv(g_s.sock,&op,&pay,&pl)!=0) return -1;
    if(op==AFC_OP_DATA && pl>=20){ memcpy(out,pay,20); free(pay); return 0; }
    free(pay); return -1;
}
/* Recursive content size/counts, computed client-side with proven READ_DIR+GET_FILE_INFO
 * (the device's own 0x21 op is unverified here). Depth-bounded against pathological trees. */
static void afc_tree_size(const char *dir, unsigned long long *bytes,
                          unsigned long long *files, unsigned long long *dirs, int depth){
    char **names=NULL; int count=0,i;
    if(depth>64) return;
    if(afc_read_dir_names(dir,&names,&count)!=0) return;
    for(i=0;i<count;i++){
        char child[AFC_PATHMAX]; unsigned char *blob=NULL; int bl=0; char v[64];
        if(strcmp(dir,"/")==0) snprintf(child,sizeof(child),"/%s",names[i]);
        else                   snprintf(child,sizeof(child),"%s/%s",dir,names[i]);
        if(afc_get_file_info(g_s.sock,child,&g_s.pkt,&blob,&bl)==0){
            int isdir = (afc_kv_lookup(blob,bl,"st_ifmt",v,sizeof(v))==0 && !strcmp(v,"S_IFDIR"));
            if(isdir){ (*dirs)++; afc_tree_size(child,bytes,files,dirs,depth+1); }
            else { (*files)++; if(afc_kv_lookup(blob,bl,"st_size",v,sizeof(v))==0) *bytes += strtoull(v,NULL,10); }
        }
        free(blob); free(names[i]);
    }
    free(names);
}

typedef struct { WIN32_FIND_DATAW *items; int count; int idx; } afc_enum_t;

static void fill_find_data(WIN32_FIND_DATAW *fd, const char *afcdir, const char *name){
    char full[AFC_PATHMAX]; unsigned char *blob=NULL; int bl=0; char v[64];
    memset(fd,0,sizeof(*fd));
    MultiByteToWideChar(CP_UTF8,0,name,-1,fd->cFileName,MAX_PATH);
    fd->dwFileAttributes=FILE_ATTRIBUTE_NORMAL;
    if(strcmp(afcdir,"/")==0) snprintf(full,sizeof(full),"/%s",name);
    else                      snprintf(full,sizeof(full),"%s/%s",afcdir,name);
    if(afc_get_file_info(g_s.sock,full,&g_s.pkt,&blob,&bl)==0){
        int isdir=0;
        if(afc_kv_lookup(blob,bl,"st_ifmt",v,sizeof(v))==0 && strcmp(v,"S_IFDIR")==0) isdir=1;
        if(isdir) fd->dwFileAttributes=FILE_ATTRIBUTE_DIRECTORY;
        else if(afc_kv_lookup(blob,bl,"st_size",v,sizeof(v))==0){
            unsigned long long sz=strtoull(v,NULL,10);
            fd->nFileSizeLow=(DWORD)(sz & 0xFFFFFFFFULL); fd->nFileSizeHigh=(DWORD)(sz>>32);
        }
        if(afc_kv_lookup(blob,bl,"st_mtime",v,sizeof(v))==0)     ns_to_filetime(strtoull(v,NULL,10),&fd->ftLastWriteTime);
        if(afc_kv_lookup(blob,bl,"st_birthtime",v,sizeof(v))==0) ns_to_filetime(strtoull(v,NULL,10),&fd->ftCreationTime);
    }
    free(blob);
}

static void find_w_to_a(const WIN32_FIND_DATAW *w, WIN32_FIND_DATAA *a){
    memset(a,0,sizeof(*a));
    a->dwFileAttributes=w->dwFileAttributes;
    a->ftCreationTime=w->ftCreationTime; a->ftLastAccessTime=w->ftLastAccessTime; a->ftLastWriteTime=w->ftLastWriteTime;
    a->nFileSizeHigh=w->nFileSizeHigh; a->nFileSizeLow=w->nFileSizeLow;
    WideCharToMultiByte(CP_ACP,0,w->cFileName,-1,a->cFileName,MAX_PATH,NULL,NULL);
}

/* a one-entry synthetic directory listing (an ancestor of the jail: var, mobile, Media) */
static HANDLE make_synth_dir(const char *utf8name, WIN32_FIND_DATAW *FindData){
    afc_enum_t *e=(afc_enum_t*)malloc(sizeof(afc_enum_t));
    e->items=(WIN32_FIND_DATAW*)calloc(1,sizeof(WIN32_FIND_DATAW));
    e->count=0; e->idx=0;
    { WIN32_FIND_DATAW *fd=&e->items[e->count++];
      memset(fd,0,sizeof(*fd));
      MultiByteToWideChar(CP_UTF8,0,utf8name,-1,fd->cFileName,MAX_PATH);
      fd->dwFileAttributes=FILE_ATTRIBUTE_DIRECTORY; }
    *FindData=e->items[0]; e->idx=1;
    return (HANDLE)e;
}

/* ================================ WFX exports ================================ */
int __stdcall FsInitW(int PluginNr, tProgressProcW pPro, tLogProcW pLog, tRequestProcW pReq){
    g_plugin_nr=PluginNr; g_progressW=pPro; g_logW=pLog; g_requestW=pReq;
    DBG("[AppleAFC] FsInitW pluginNr=%d", PluginNr);
    return 0;
}
int __stdcall FsInit(int PluginNr, tProgressProc pPro, tLogProc pLog, tRequestProc pReq){
    g_plugin_nr=PluginNr; (void)pPro; (void)pLog; (void)pReq; return 0;
}

void __stdcall FsGetDefRootName(char* DefRootName, int maxlen){
    lstrcpynA(DefRootName,"Apple AFC",maxlen);
}
void __stdcall FsSetDefaultParams(FsDefaultParamStruct* dps){
    if(dps && dps->size>=(int)sizeof(*dps)){
        strncpy(g_ini_ansi,dps->DefaultIniName,sizeof(g_ini_ansi)-1); g_ini_ansi[sizeof(g_ini_ansi)-1]=0;
        DBG("[AppleAFC] DefaultIniName=\"%s\"", g_ini_ansi);
    }
}
int  __stdcall FsGetBackgroundFlags(void){ return BG_DOWNLOAD|BG_UPLOAD; }
/* FsStatusInfoW / FsStatusInfo are defined further down, after the directory-time helpers */

HANDLE __stdcall FsFindFirstW(WCHAR* Path, WIN32_FIND_DATAW *FindData){
    char afc[AFC_PATHMAX], synth[256]; char **names=NULL; int count=0,i; afc_enum_t *e; int kind;
    memset(FindData,0,sizeof(*FindData));
    kind = tc_classify(Path,synth,sizeof(synth),afc,sizeof(afc));
    DBG("[AppleAFC] FindFirst path=\"%ls\" kind=%d synth=\"%s\" afc=\"%s\"",
        Path, kind, kind==0?synth:"", kind==1?afc:"");

    if(kind==0) return make_synth_dir(synth,FindData);           /* synthetic ancestor of the jail */
    if(kind<0){ SetLastError(ERROR_PATH_NOT_FOUND); return INVALID_HANDLE_VALUE; }

    if(!g_s.connected){                                          /* lazy connect on first service entry */
        if(afc_connect_session()!=0){
            DBG("[AppleAFC] connect FAILED: %s", g_s.last_error);
            wlog(MSGTYPE_IMPORTANTERROR, g_s.last_error[0]?g_s.last_error:"AFC: could not connect to the device.");
            { WCHAR w[600]; MultiByteToWideChar(CP_UTF8,0,g_s.last_error,-1,w,600);
              MessageBoxW(GetActiveWindow(),w,L"Apple AFC -- connection failed",MB_OK|MB_ICONWARNING); }
            SetLastError(ERROR_PATH_NOT_FOUND); return INVALID_HANDLE_VALUE;
        }
        { char ok[256]; snprintf(ok,sizeof(ok),"Connected to %s over %s (AFC %s).",
              g_s.model[0]?g_s.model:"device", g_s.conn_type, g_s.afc_version[0]?g_s.afc_version:"?");
          wlog(MSGTYPE_CONNECTCOMPLETE, ok); }
    }
    if(afc_read_dir_names(afc,&names,&count)!=0){
        /* The held socket may have died mid-session (e.g. cable pulled then re-inserted).
         * Drop it and try one reconnect + relist so browsing recovers on refresh. Transfers
         * deliberately do NOT do this — an interrupted copy aborts with an error instead. */
        DBG("[AppleAFC] FindFirst: dir read failed; dropping socket and retrying once");
        afc_disconnect_session();
        if(afc_connect_session()!=0 || afc_read_dir_names(afc,&names,&count)!=0){
            SetLastError(ERROR_PATH_NOT_FOUND); return INVALID_HANDLE_VALUE;
        }
    }
    if(g_cp_depth>0) cp_add_dir(afc);                            /* in a copy op: record dir (incl. empty) for end-of-op stamping */
    e=(afc_enum_t*)malloc(sizeof(afc_enum_t));
    e->items=(WIN32_FIND_DATAW*)calloc((size_t)(count>0?count:1),sizeof(WIN32_FIND_DATAW));
    e->count=0; e->idx=0;
    for(i=0;i<count;i++){ fill_find_data(&e->items[e->count++],afc,names[i]); free(names[i]); }
    free(names);
    if(e->count==0){ free(e->items); free(e); SetLastError(ERROR_NO_MORE_FILES); return INVALID_HANDLE_VALUE; }
    *FindData=e->items[0]; e->idx=1;
    return (HANDLE)e;
}
BOOL __stdcall FsFindNextW(HANDLE Hdl, WIN32_FIND_DATAW *FindData){
    afc_enum_t *e=(afc_enum_t*)Hdl;
    if(!e || e->idx>=e->count) return FALSE;
    *FindData=e->items[e->idx++]; return TRUE;
}
HANDLE __stdcall FsFindFirst(char* Path, WIN32_FIND_DATAA *FindData){
    WCHAR wpath[AFC_PATHMAX]; WIN32_FIND_DATAW wfd; HANDLE h;
    MultiByteToWideChar(CP_ACP,0,Path,-1,wpath,AFC_PATHMAX);
    h=FsFindFirstW(wpath,&wfd);
    if(h!=INVALID_HANDLE_VALUE) find_w_to_a(&wfd,FindData);
    return h;
}
BOOL __stdcall FsFindNext(HANDLE Hdl, WIN32_FIND_DATAA *FindData){
    WIN32_FIND_DATAW wfd;
    if(!FsFindNextW(Hdl,&wfd)) return FALSE;
    find_w_to_a(&wfd,FindData); return TRUE;
}
int __stdcall FsFindClose(HANDLE Hdl){
    afc_enum_t *e=(afc_enum_t*)Hdl;
    if(e){ free(e->items); free(e); }
    return 0;
}

int __stdcall FsExtractCustomIconW(WCHAR* RemoteName, int ExtractFlags, HICON* TheIcon){
    DBG("[AppleAFC] IconReq name=\"%ls\" flags=%d", RemoteName?RemoteName:L"(null)", ExtractFlags);
    if(path_is_root(RemoteName) || path_is_mount(RemoteName)){    /* plugin root + the Media mount */
        int sz = (ExtractFlags & FS_ICONFLAG_SMALL) ? 16 : 32;
        *TheIcon=(HICON)LoadImageW(g_hinst,MAKEINTRESOURCEW(IDI_AFC),IMAGE_ICON,sz,sz,LR_DEFAULTCOLOR);
        if(!*TheIcon) *TheIcon=LoadIconW(g_hinst,MAKEINTRESOURCEW(IDI_AFC));
        DBG("[AppleAFC] LoadIcon hinst=%p id=%d size=%d -> %p", (void*)g_hinst, IDI_AFC, sz, (void*)*TheIcon);
        if(*TheIcon) return FS_ICON_EXTRACTED_DESTROY;
    }
    return FS_ICON_USEDEFAULT;
}
int __stdcall FsExtractCustomIcon(char* RemoteName, int ExtractFlags, HICON* TheIcon){
    WCHAR w[AFC_PATHMAX];
    MultiByteToWideChar(CP_ACP,0,RemoteName,-1,w,AFC_PATHMAX);
    return FsExtractCustomIconW(w,ExtractFlags,TheIcon);
}

BOOL __stdcall FsDisconnectW(WCHAR* DisconnectRoot){ (void)DisconnectRoot; afc_disconnect_session(); return TRUE; }
BOOL __stdcall FsDisconnect (char*  DisconnectRoot){ (void)DisconnectRoot; afc_disconnect_session(); return TRUE; }

/* ------------------------------- transfers (Step 2) ------------------------------- */
#define DL_CHUNK 65536
#define UL_CHUNK 32768

/* progress to TC; returns nonzero if the user pressed cancel */
static int report_progress(WCHAR *src, WCHAR *dst, unsigned long long done, unsigned long long total){
    int pct = (total>0) ? (int)((done*100ULL)/total) : 0;
    if(pct>100) pct=100;
    return g_progressW ? g_progressW(g_plugin_nr,src,dst,pct) : 0;
}

/* mirror a Windows FILETIME onto a device path (AFC SET_FILE_TIME 0x1E, mtime in ns, number-first) */
static int afc_set_mtime(const char *afcpath, const FILETIME *ft){
    unsigned long long ftv = ((unsigned long long)ft->dwHighDateTime<<32) | ft->dwLowDateTime;
    unsigned long long ns; int pl; unsigned char *p; long long st;
    if(ftv < 116444736000000000ULL) return 0;                     /* pre-1970 -> nothing to do */
    ns = (ftv - 116444736000000000ULL) * 100ULL;                  /* 100ns-since-1601 -> ns-since-1970 */
    pl = (int)strlen(afcpath);
    p = (unsigned char*)malloc((size_t)8+pl+1);
    put_le64(p, ns);                                              /* [mtime:8] ... */
    memcpy(p+8, afcpath, (size_t)pl+1);                           /* ... path\0  */
    st = afc_status_op(g_s.sock, AFC_OP_SET_FILE_TIME, p, 8+pl+1, &g_s.pkt, "set_file_time");
    DBG("[AppleAFC] set_file_time path=\"%s\" afc_status=%lld", afcpath, (long long)st);
    free(p);
    return st==0 ? 0 : -1;
}

/* ---- "Copy date/time of directories" awareness ----
 * The dir-timestamp option is wincmd.ini [Configuration] CopyDirTimeStamp (0/1). A plugin finds
 * wincmd.ini via %COMMANDER_INI% (always set when run from TC 6.55+); if that ever fails we fall
 * back to the DefaultIniName TC handed us. Resolved once, value re-read per operation so toggling
 * the checkbox takes effect without reloading the plugin. */
static int resolve_wincmd_ini(WCHAR *out, int cap){
    DWORD n = GetEnvironmentVariableW(L"COMMANDER_INI", out, (DWORD)cap);
    if(n>0 && n<(DWORD)cap) return 1;
    if(g_ini_ansi[0]){ MultiByteToWideChar(CP_ACP,0,g_ini_ansi,-1,out,cap); return 1; }
    return 0;
}
static int tc_dir_timestamp_on(void){
    WCHAR ini[MAX_PATH];
    if(!resolve_wincmd_ini(ini,MAX_PATH)) return 1;              /* can't find ini: keep prior behaviour */
    return GetPrivateProfileIntW(L"Configuration",L"CopyDirTimeStamp",0,ini) ? 1 : 0;  /* TC default: off */
}

/* ---- "Verify after copy" awareness ----
 * TC's Copy/Delete option "Verify after copy (MD5/BLAKE3 checksum)" lives in wincmd.ini as
 * [Configuration] VerifyCopy. We read it only as an on/off intent (any nonzero == on) and
 * re-read per copy so toggling the checkbox takes effect without reloading. The plugin always
 * verifies with SHA-1 irrespective of TC's MD5/BLAKE3 selection, because the AFC hash op
 * (GET_FILE_HASH 0x1D) returns SHA-1 -- so the device hands us a SHA-1 for free and we compute
 * the local side to match. */
static int tc_verify_copy_on(void){
    WCHAR ini[MAX_PATH];
    if(!resolve_wincmd_ini(ini,MAX_PATH)) return 0;              /* can't find ini: don't verify */
    return GetPrivateProfileIntW(L"Configuration",L"VerifyCopy",0,ini) ? 1 : 0;  /* TC default: off */
}

/* Local-side SHA-1 of a file via legacy CryptoAPI (CALG_SHA1, present in PROV_RSA_FULL on XP).
 * Streams the file so large media never need to be buffered whole. 0 on success, -1 otherwise. */
static int local_file_sha1(const WCHAR *path, unsigned char out[20]){
    HCRYPTPROV prov=0; HCRYPTHASH hash=0; HANDLE f; int rc=-1;
    f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_FLAG_SEQUENTIAL_SCAN,NULL);
    if(f==INVALID_HANDLE_VALUE) return -1;
    if(CryptAcquireContextW(&prov,NULL,NULL,PROV_RSA_FULL,CRYPT_VERIFYCONTEXT) &&
       CryptCreateHash(prov,CALG_SHA1,0,0,&hash)){
        unsigned char buf[65536]; DWORD rd=0; int ok=1;
        for(;;){
            if(!ReadFile(f,buf,sizeof(buf),&rd,NULL)){ ok=0; break; }  /* read error: do NOT pass a short hash */
            if(rd==0) break;                                          /* EOF */
            if(!CryptHashData(hash,buf,rd,0)){ ok=0; break; }
        }
        if(ok){ DWORD hl=20; if(CryptGetHashParam(hash,HP_HASHVAL,out,&hl,0) && hl==20) rc=0; }
    }
    if(hash) CryptDestroyHash(hash);
    if(prov) CryptReleaseContext(prov,0);
    CloseHandle(f);
    return rc;
}

/* Verify a just-transferred file: local SHA-1 vs the device's GET_FILE_HASH.
 *    1 = verified match
 *    0 = MISMATCH (caller should fail the copy)
 *   -1 = could not verify (a hash was unavailable) -> caller treats as pass: the bytes did
 *        transfer and an unavailable hash is not a definitive mismatch. */
static int verify_copy_sha1(const WCHAR *localpath, const char *afcpath){
    unsigned char ldig[20], ddig[20];
    if(local_file_sha1(localpath,ldig)!=0){ DBG("[AppleAFC] verify: local SHA-1 unavailable -> skip"); return -1; }
    if(afc_file_sha1(afcpath,ddig)!=0){     DBG("[AppleAFC] verify: device SHA-1 unavailable -> skip"); return -1; }
    if(memcmp(ldig,ddig,20)==0){ DBG("[AppleAFC] verify: SHA-1 match \"%s\"", afcpath); return 1; }
    DBG("[AppleAFC] verify: SHA-1 MISMATCH \"%s\"", afcpath);
    return 0;
}

/* User-facing notice on a verification mismatch (no auto-delete: the bytes are left in place). */
static void verify_fail_box(const WCHAR *localpath, const char *afcpath, int upload){
    WCHAR msg[AFC_PATHMAX*2+384], wdev[AFC_PATHMAX];
    MultiByteToWideChar(CP_UTF8,0,afcpath,-1,wdev,AFC_PATHMAX);
    _snwprintf(msg,sizeof(msg)/sizeof(msg[0]),
        L"Checksum verification failed after %ls.\n\n"
        L"The SHA-1 of the local file and the device file do not match, so the copied file "
        L"may be corrupt.\n\nLocal:  %ls\nDevice: %ls",
        upload?L"upload":L"download", localpath, wdev);
    msg[sizeof(msg)/sizeof(msg[0])-1]=0;
    MessageBoxW(GetActiveWindow(),msg,L"Apple AFC \x2014 Verify after copy",MB_OK|MB_ICONWARNING);
}

/* ---- directory-time replication ----
 * TC never calls FsSetTime for plugin directories, and FsMkDir gets only the destination path,
 * so the source date isn't directly available. But FsPutFile reveals the local source file
 * path, which anchors the local<->device mapping: from one upload we can recover the local
 * original of every directory we created this operation. We record those directories, learn
 * the anchor on the first upload, and stamp them at operation end (FsStatusInfo END) -- after
 * all file writes, so nothing re-bumps the directory mtimes. */
/* (replication state is declared up with the other globals) */
#undef  CP_UP
#undef  CP_DOWN
#define CP_UP   1                        /* PC -> device: stamp device dirs from local   */
#define CP_DOWN 2                        /* device -> PC: stamp local dirs from device   */

static void cp_reset(void){
    int i; for(i=0;i<g_cp_ndirs;i++) free(g_cp_dirs[i]);
    g_cp_ndirs=0; g_cp_anchor=0; g_cp_dir=0; g_cp_lpre[0]=0; g_cp_rpre[0]=0;
}
static void cp_add_dir(const char *afc){                          /* dedups */
    int i; for(i=0;i<g_cp_ndirs;i++) if(strcmp(g_cp_dirs[i],afc)==0) return;
    if(g_cp_ndirs>=g_cp_capdirs){ g_cp_capdirs=g_cp_capdirs?g_cp_capdirs*2:16;
        g_cp_dirs=(char**)realloc(g_cp_dirs,(size_t)g_cp_capdirs*sizeof(char*)); }
    g_cp_dirs[g_cp_ndirs]=(char*)malloc(strlen(afc)+1); strcpy(g_cp_dirs[g_cp_ndirs],afc); g_cp_ndirs++;
}
/* downloads give us files, not dirs: record a device source dir and all its ancestors up to
 * the anchor, so directories that contain only sub-directories still get stamped. */
static void cp_collect_ancestors(const char *devdir){
    char d[AFC_PATHMAX]; size_t rl=strlen(g_cp_rpre); char *slash;
    if(rl==0) return;
    snprintf(d,sizeof(d),"%s",devdir);
    while(strlen(d)>rl && strncmp(d,g_cp_rpre,rl)==0){
        cp_add_dir(d);
        slash=strrchr(d,'/'); if(!slash || slash==d) break; *slash=0;
    }
}
static void cp_set_anchor(const WCHAR *localW, const char *afc){
    char lu8[AFC_PATHMAX], lwork[AFC_PATHMAX], rwork[AFC_PATHMAX];
    char *lc[128], *rc[128], *tok, *p; int ln=0, rn=0, k=0, i;
    WideCharToMultiByte(CP_UTF8,0,localW,-1,lu8,sizeof(lu8),NULL,NULL);
    for(p=lu8;*p;p++) if(*p=='\\') *p='/';
    snprintf(lwork,sizeof(lwork),"%s",lu8); snprintf(rwork,sizeof(rwork),"%s",afc);
    for(tok=strtok(lwork,"/"); tok && ln<128; tok=strtok(NULL,"/")) lc[ln++]=tok;
    for(tok=strtok(rwork,"/"); tok && rn<128; tok=strtok(NULL,"/")) rc[rn++]=tok;
    while(k<ln-1 && k<rn-1 && strcmp(lc[ln-1-k],rc[rn-1-k])==0) k++;   /* longest common tail, keep >=1 each */
    g_cp_lpre[0]=0;
    for(i=0;i<ln-k;i++){ if(i) strncat(g_cp_lpre,"/",sizeof(g_cp_lpre)-strlen(g_cp_lpre)-1);
                         strncat(g_cp_lpre,lc[i],sizeof(g_cp_lpre)-strlen(g_cp_lpre)-1); }
    g_cp_rpre[0]=0;
    for(i=0;i<rn-k;i++){ strncat(g_cp_rpre,"/",sizeof(g_cp_rpre)-strlen(g_cp_rpre)-1);
                         strncat(g_cp_rpre,rc[i],sizeof(g_cp_rpre)-strlen(g_cp_rpre)-1); }
    g_cp_anchor=1;
    DBG("[AppleAFC] cp_anchor local=\"%s\" remote=\"%s\"", g_cp_lpre, g_cp_rpre);
}
static void cp_finalize(void){
    int i; size_t rl;
    if(!g_cp_anchor || g_cp_ndirs==0 || !g_s.connected) return;
    if(!tc_dir_timestamp_on()){ DBG("[AppleAFC] CopyDirTimeStamp off -- not stamping directories"); return; }
    rl=strlen(g_cp_rpre);
    for(i=0;i<g_cp_ndirs;i++){
        const char *d=g_cp_dirs[i]; size_t dl=strlen(d); char lpath[AFC_PATHMAX]; WCHAR lw[AFC_PATHMAX]; char *p;
        if(dl<=rl || strncmp(d,g_cp_rpre,rl)!=0) continue;       /* must live under the copy-root parent  */
        if(g_cp_rpre[rl-1]!='/' && d[rl]!='/') continue;         /* strict descendant, not a name-prefix  */
        snprintf(lpath,sizeof(lpath),"%s%s",g_cp_lpre,d+rl);      /* device path -> local path */
        for(p=lpath;*p;p++) if(*p=='/') *p='\\';
        MultiByteToWideChar(CP_UTF8,0,lpath,-1,lw,AFC_PATHMAX);
        if(g_cp_dir==CP_DOWN){
            /* stamp the LOCAL directory with the DEVICE source date */
            unsigned char *blob=NULL; int bl=0; char v[64]; FILETIME ft; HANDLE h;
            if(afc_get_file_info(g_s.sock,d,&g_s.pkt,&blob,&bl)==0 && afc_kv_lookup(blob,bl,"st_mtime",v,sizeof(v))==0){
                ns_to_filetime(strtoull(v,NULL,10),&ft);
                h=CreateFileW(lw,FILE_WRITE_ATTRIBUTES,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS,NULL);
                if(h!=INVALID_HANDLE_VALUE){ SetFileTime(h,NULL,NULL,&ft); CloseHandle(h);
                    DBG("[AppleAFC] cp_finalize(local) dir=\"%s\" <- device=\"%s\"", lpath, d); }
                else DBG("[AppleAFC] cp_finalize(local) open failed: %s", lpath);
            }
            free(blob);
        } else {
            /* stamp the DEVICE directory with the LOCAL source date */
            WIN32_FILE_ATTRIBUTE_DATA fad;
            if(GetFileAttributesExW(lw,GetFileExInfoStandard,&fad)){
                afc_set_mtime(d,&fad.ftLastWriteTime);
                DBG("[AppleAFC] cp_finalize(device) dir=\"%s\" <- local=\"%s\"", d, lpath);
            } else DBG("[AppleAFC] cp_finalize(device) local not found: %s", lpath);
        }
    }
}
/* depth-counted so only the OUTERMOST operation triggers reset/finalize (in case TC nests) */
static void cp_status(int startEnd){
    if(startEnd==FS_STATUS_START){ if(g_cp_depth==0) cp_reset(); g_cp_depth++; }
    else { if(g_cp_depth>0) g_cp_depth--; if(g_cp_depth==0){ cp_finalize(); cp_reset(); } }
}

void __stdcall FsStatusInfoW(WCHAR* RemoteDir, int InfoStartEnd, int InfoOperation){
    (void)RemoteDir;
    DBG("[AppleAFC] StatusInfo start/end=%d op=%d ndirs=%d depth=%d", InfoStartEnd, InfoOperation, g_cp_ndirs, g_cp_depth);
    cp_status(InfoStartEnd);
}
void __stdcall FsStatusInfo (char*  RemoteDir, int InfoStartEnd, int InfoOperation){ (void)RemoteDir;(void)InfoOperation; cp_status(InfoStartEnd); }

/* download: device -> PC */
int __stdcall FsGetFileW(WCHAR* RemoteName, WCHAR* LocalName, int CopyFlags, RemoteInfoStruct* ri){
    char afc[AFC_PATHMAX], synth[256]; int kind, rc=FS_FILE_OK, aborted=0;
    uint64_t handle=0; unsigned long long total=0, done=0; HANDLE lf;

    kind=tc_classify(RemoteName,synth,sizeof(synth),afc,sizeof(afc));
    if(kind!=1) return FS_FILE_NOTFOUND;                          /* only real files under the jail */
    if(!g_s.connected && afc_connect_session()!=0) return FS_FILE_READERROR;
    DBG("[AppleAFC] GetFile afc=\"%s\" -> \"%ls\" flags=%d", afc, LocalName, CopyFlags);

    if(!(CopyFlags & (FS_COPYFLAGS_OVERWRITE|FS_COPYFLAGS_RESUME))){
        if(GetFileAttributesW(LocalName)!=INVALID_FILE_ATTRIBUTES) return FS_FILE_EXISTS;
    }

    if(ri && (ri->SizeLow || ri->SizeHigh))
        total = ((unsigned long long)ri->SizeHigh<<32) | ri->SizeLow;
    else {
        unsigned char *blob=NULL; int bl=0; char v[64];
        if(afc_get_file_info(g_s.sock,afc,&g_s.pkt,&blob,&bl)==0 && afc_kv_lookup(blob,bl,"st_size",v,sizeof(v))==0)
            total=strtoull(v,NULL,10);
        free(blob);
    }

    if(afc_open(g_s.sock,afc,AFC_FOPEN_RDONLY,&g_s.pkt,&handle)!=0) return FS_FILE_READERROR;
    lf=CreateFileW(LocalName,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if(lf==INVALID_HANDLE_VALUE){ afc_close(g_s.sock,handle,&g_s.pkt); return FS_FILE_WRITEERROR; }

    for(;;){
        unsigned char *buf=NULL; int got=0; DWORD wr=0;
        if(afc_read_once(g_s.sock,handle,DL_CHUNK,&g_s.pkt,&buf,&got)!=0){ free(buf); rc=FS_FILE_READERROR; break; }
        if(got<=0){ free(buf); break; }                          /* EOF */
        if(!WriteFile(lf,buf,(DWORD)got,&wr,NULL) || wr!=(DWORD)got){ free(buf); rc=FS_FILE_WRITEERROR; break; }
        free(buf);
        done += (unsigned long long)got;
        if(report_progress(RemoteName,LocalName,done,total)){ aborted=1; break; }
    }
    afc_close(g_s.sock,handle,&g_s.pkt);
    if(rc==FS_FILE_OK && !aborted && ri) SetFileTime(lf,NULL,NULL,&ri->LastWriteTime);  /* stamp device mtime */
    CloseHandle(lf);

    if(aborted){ DeleteFileW(LocalName); return FS_FILE_USERABORT; }
    if(rc!=FS_FILE_OK){ DeleteFileW(LocalName); return rc; }
    if(tc_verify_copy_on() && verify_copy_sha1(LocalName,afc)==0){ /* definitive mismatch: fail, leave file in place */
        verify_fail_box(LocalName,afc,0); return FS_FILE_READERROR; }
    if(!g_cp_anchor) cp_set_anchor(LocalName,afc);                /* learn map (anchor before collect) */
    g_cp_dir=CP_DOWN;
    { char devdir[AFC_PATHMAX]; char *s; snprintf(devdir,sizeof(devdir),"%s",afc);
      s=strrchr(devdir,'/'); if(s && s!=devdir) *s=0; else { devdir[0]='/'; devdir[1]=0; }
      cp_collect_ancestors(devdir); }                            /* this dir + ancestors -> stamp at end */
    if(CopyFlags & FS_COPYFLAGS_MOVE)                              /* move = copy + delete source */
        afc_status_op(g_s.sock,AFC_OP_REMOVE_PATH,(const unsigned char*)afc,(int)strlen(afc)+1,&g_s.pkt,"remove(after move)");
    return FS_FILE_OK;
}

/* upload: PC -> device */
int __stdcall FsPutFileW(WCHAR* LocalName, WCHAR* RemoteName, int CopyFlags){
    char afc[AFC_PATHMAX], synth[256]; int kind, rc=FS_FILE_OK, aborted=0;
    uint64_t handle=0; unsigned long long total=0, done=0; HANDLE lf; LARGE_INTEGER li; unsigned char *buf;

    kind=tc_classify(RemoteName,synth,sizeof(synth),afc,sizeof(afc));
    if(kind!=1) return FS_FILE_NOTFOUND;                          /* cannot write outside the jail */
    if(!g_s.connected && afc_connect_session()!=0) return FS_FILE_WRITEERROR;
    DBG("[AppleAFC] PutFile \"%ls\" -> afc=\"%s\" flags=%d", LocalName, afc, CopyFlags);

    if(!(CopyFlags & (FS_COPYFLAGS_OVERWRITE|FS_COPYFLAGS_RESUME))){
        unsigned char *blob=NULL; int bl=0;
        if(afc_get_file_info(g_s.sock,afc,&g_s.pkt,&blob,&bl)==0){ free(blob); return FS_FILE_EXISTS; }
        free(blob);
    }

    lf=CreateFileW(LocalName,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(lf==INVALID_HANDLE_VALUE) return FS_FILE_NOTFOUND;
    if(GetFileSizeEx(lf,&li)) total=(unsigned long long)li.QuadPart;

    if(afc_open(g_s.sock,afc,AFC_FOPEN_WRONLY,&g_s.pkt,&handle)!=0){ CloseHandle(lf); return FS_FILE_WRITEERROR; }
    buf=(unsigned char*)malloc(UL_CHUNK);
    for(;;){
        DWORD rd=0;
        if(!ReadFile(lf,buf,UL_CHUNK,&rd,NULL)){ rc=FS_FILE_READERROR; break; }
        if(rd==0) break;                                          /* EOF */
        if(afc_write_once(g_s.sock,handle,buf,(int)rd,&g_s.pkt) < 0){ rc=FS_FILE_WRITEERROR; break; }
        done += rd;
        if(report_progress(LocalName,RemoteName,done,total)){ aborted=1; break; }
    }
    free(buf);
    afc_close(g_s.sock,handle,&g_s.pkt);
    { FILETIME ftw;                                               /* mirror the local mtime onto the device */
      if(rc==FS_FILE_OK && !aborted && GetFileTime(lf,NULL,NULL,&ftw)) afc_set_mtime(afc,&ftw); }
    CloseHandle(lf);

    if(aborted){ afc_status_op(g_s.sock,AFC_OP_REMOVE_PATH,(const unsigned char*)afc,(int)strlen(afc)+1,&g_s.pkt,"remove(abort)"); return FS_FILE_USERABORT; }
    if(rc!=FS_FILE_OK) return rc;
    if(tc_verify_copy_on() && verify_copy_sha1(LocalName,afc)==0){ /* definitive mismatch: fail, leave device file in place */
        verify_fail_box(LocalName,afc,1); return FS_FILE_WRITEERROR; }
    if(!g_cp_anchor) cp_set_anchor(LocalName,afc);                /* learn local<->device map for dir times */
    g_cp_dir=CP_UP;
    if(CopyFlags & FS_COPYFLAGS_MOVE) DeleteFileW(LocalName);
    return FS_FILE_OK;
}

int __stdcall FsGetFile(char* RemoteName, char* LocalName, int CopyFlags, RemoteInfoStruct* ri){
    WCHAR wr[AFC_PATHMAX], wl[AFC_PATHMAX];
    MultiByteToWideChar(CP_ACP,0,RemoteName,-1,wr,AFC_PATHMAX);
    MultiByteToWideChar(CP_ACP,0,LocalName,-1,wl,AFC_PATHMAX);
    return FsGetFileW(wr,wl,CopyFlags,ri);
}
int __stdcall FsPutFile(char* LocalName, char* RemoteName, int CopyFlags){
    WCHAR wl[AFC_PATHMAX], wr[AFC_PATHMAX];
    MultiByteToWideChar(CP_ACP,0,LocalName,-1,wl,AFC_PATHMAX);
    MultiByteToWideChar(CP_ACP,0,RemoteName,-1,wr,AFC_PATHMAX);
    return FsPutFileW(wl,wr,CopyFlags);
}

/* ------------------------------- mutating ops (Step 3) ------------------------------- */
/* All operate only on real paths under the jail; the jail root "/" and the synthetic
 * ancestors are refused so a stray F8 can never try to wipe /var/mobile/Media wholesale. */

BOOL __stdcall FsMkDirW(WCHAR* Path){
    char afc[AFC_PATHMAX], synth[256]; int kind;
    kind=tc_classify(Path,synth,sizeof(synth),afc,sizeof(afc));
    if(kind!=1) return FALSE;                                     /* cannot create synthetic levels */
    if(!g_s.connected && afc_connect_session()!=0) return FALSE;
    DBG("[AppleAFC] MkDir afc=\"%s\"", afc);
    if(afc_status_op(g_s.sock,AFC_OP_MAKE_DIR,(const unsigned char*)afc,(int)strlen(afc)+1,&g_s.pkt,"mkdir")!=0) return FALSE;
    cp_add_dir(afc);                                              /* remember it for end-of-op time stamping */
    return TRUE;
}
BOOL __stdcall FsMkDir(char* Path){
    WCHAR w[AFC_PATHMAX]; MultiByteToWideChar(CP_ACP,0,Path,-1,w,AFC_PATHMAX); return FsMkDirW(w);
}

BOOL __stdcall FsDeleteFileW(WCHAR* RemoteName){
    char afc[AFC_PATHMAX], synth[256]; int kind;
    kind=tc_classify(RemoteName,synth,sizeof(synth),afc,sizeof(afc));
    if(kind!=1 || strcmp(afc,"/")==0) return FALSE;
    if(!g_s.connected && afc_connect_session()!=0) return FALSE;
    DBG("[AppleAFC] DeleteFile afc=\"%s\"", afc);
    return afc_status_op(g_s.sock,AFC_OP_REMOVE_PATH,(const unsigned char*)afc,(int)strlen(afc)+1,&g_s.pkt,"remove(file)")==0 ? TRUE : FALSE;
}
BOOL __stdcall FsDeleteFile(char* RemoteName){
    WCHAR w[AFC_PATHMAX]; MultiByteToWideChar(CP_ACP,0,RemoteName,-1,w,AFC_PATHMAX); return FsDeleteFileW(w);
}

BOOL __stdcall FsRemoveDirW(WCHAR* RemoteName){
    char afc[AFC_PATHMAX], synth[256]; int kind; long long st;
    kind=tc_classify(RemoteName,synth,sizeof(synth),afc,sizeof(afc));
    if(kind!=1 || strcmp(afc,"/")==0) return FALSE;               /* never the jail root */
    if(!g_s.connected && afc_connect_session()!=0) return FALSE;
    DBG("[AppleAFC] RemoveDir afc=\"%s\"", afc);
    st=afc_status_op(g_s.sock,AFC_OP_REMOVE_PATH,(const unsigned char*)afc,(int)strlen(afc)+1,&g_s.pkt,"rmdir(empty)");
    if(st==0) return TRUE;                                        /* dir was empty */
    st=afc_status_op(g_s.sock,AFC_OP_REMOVE_PATH_AND_CONTENTS,(const unsigned char*)afc,(int)strlen(afc)+1,&g_s.pkt,"rmdir(recursive)");
    return st==0 ? TRUE : FALSE;                                  /* non-empty -> recursive removal */
}
BOOL __stdcall FsRemoveDir(char* RemoteName){
    WCHAR w[AFC_PATHMAX]; MultiByteToWideChar(CP_ACP,0,RemoteName,-1,w,AFC_PATHMAX); return FsRemoveDirW(w);
}

/* rename or move within the device (RENAME_PATH is server-side, like rename(2)) */
int __stdcall FsRenMovFileW(WCHAR* OldName, WCHAR* NewName, BOOL Move, BOOL OverWrite, RemoteInfoStruct* ri){
    char oafc[AFC_PATHMAX], nafc[AFC_PATHMAX], synth[256]; int ko, kn, plo, pln; unsigned char *pay; long long st;
    (void)Move; (void)ri;
    ko=tc_classify(OldName,synth,sizeof(synth),oafc,sizeof(oafc));
    kn=tc_classify(NewName,synth,sizeof(synth),nafc,sizeof(nafc));
    if(ko!=1 || kn!=1 || strcmp(oafc,"/")==0 || strcmp(nafc,"/")==0) return FS_FILE_NOTSUPPORTED;
    if(!g_s.connected && afc_connect_session()!=0) return FS_FILE_READERROR;

    if(!OverWrite){                                              /* don't silently clobber the target */
        unsigned char *blob=NULL; int bl=0;
        if(afc_get_file_info(g_s.sock,nafc,&g_s.pkt,&blob,&bl)==0){ free(blob); return FS_FILE_EXISTS; }
        free(blob);
    }
    DBG("[AppleAFC] Rename \"%s\" -> \"%s\"", oafc, nafc);
    plo=(int)strlen(oafc); pln=(int)strlen(nafc);
    pay=(unsigned char*)malloc((size_t)plo+1+pln+1);            /* old\0 new\0 */
    memcpy(pay,oafc,(size_t)plo+1);
    memcpy(pay+plo+1,nafc,(size_t)pln+1);
    st=afc_status_op(g_s.sock,AFC_OP_RENAME_PATH,pay,plo+1+pln+1,&g_s.pkt,"rename");
    free(pay);
    return st==0 ? FS_FILE_OK : FS_FILE_WRITEERROR;
}
int __stdcall FsRenMovFile(char* OldName, char* NewName, BOOL Move, BOOL OverWrite, RemoteInfoStruct* ri){
    WCHAR wo[AFC_PATHMAX], wn[AFC_PATHMAX];
    MultiByteToWideChar(CP_ACP,0,OldName,-1,wo,AFC_PATHMAX);
    MultiByteToWideChar(CP_ACP,0,NewName,-1,wn,AFC_PATHMAX);
    return FsRenMovFileW(wo,wn,Move,OverWrite,ri);
}

/* set a copied file's or directory's time to the source's. TC calls this after FsPutFile and
 * after a directory's contents are in place. AFC exposes modification time only, so we apply
 * LastWriteTime and ignore creation/access (which afc cannot set anyway). */
BOOL __stdcall FsSetTimeW(WCHAR* RemoteName, FILETIME* CreationTime, FILETIME* LastAccessTime, FILETIME* LastWriteTime){
    char afc[AFC_PATHMAX], synth[256]; int kind;
    (void)CreationTime; (void)LastAccessTime;
    kind=tc_classify(RemoteName,synth,sizeof(synth),afc,sizeof(afc));
    DBG("[AppleAFC] SetTime path=\"%ls\" kind=%d afc=\"%s\" haveCre=%d haveAcc=%d haveWri=%d",
        RemoteName, kind, kind==1?afc:"", CreationTime?1:0, LastAccessTime?1:0, LastWriteTime?1:0);
    if(kind!=1 || strcmp(afc,"/")==0) return FALSE;               /* real paths under the jail only */
    if(!LastWriteTime) return TRUE;                               /* nothing to set */
    if(!g_s.connected && afc_connect_session()!=0) return FALSE;
    return afc_set_mtime(afc,LastWriteTime)==0 ? TRUE : FALSE;
}
BOOL __stdcall FsSetTime(char* RemoteName, FILETIME* CreationTime, FILETIME* LastAccessTime, FILETIME* LastWriteTime){
    WCHAR w[AFC_PATHMAX]; MultiByteToWideChar(CP_ACP,0,RemoteName,-1,w,AFC_PATHMAX);
    return FsSetTimeW(w,CreationTime,LastAccessTime,LastWriteTime);
}

/* ============================ Properties (Step 4) ============================ */

static void numfmt_locale(const char *cnum, int digits, char *out, size_t cap){
    WCHAR num[48], sep[8], dec[8], grp[16], wout[96]; NUMBERFMTW nf; int g; WCHAR *p;
    MultiByteToWideChar(CP_ACP,0,cnum,-1,num,48);
    if(GetLocaleInfoW(LOCALE_USER_DEFAULT,LOCALE_STHOUSAND,sep,8)<=0)  wcscpy(sep,L",");
    if(GetLocaleInfoW(LOCALE_USER_DEFAULT,LOCALE_SDECIMAL, dec,8)<=0)  wcscpy(dec,L".");
    if(GetLocaleInfoW(LOCALE_USER_DEFAULT,LOCALE_SGROUPING,grp,16)<=0) wcscpy(grp,L"3;0");
    g=0; for(p=grp;*p;p++) if(*p>=L'0'&&*p<=L'9') g=g*10+(*p-L'0');   /* "3;0"->3, "3;2;0"->32 */
    if(g%10==0) g/=10;
    if(g<=0) g=3;
    nf.NumDigits=(UINT)digits; nf.LeadingZero=0; nf.Grouping=(UINT)g;
    nf.lpDecimalSep=dec; nf.lpThousandSep=sep; nf.NegativeOrder=1;
    if(GetNumberFormatW(LOCALE_USER_DEFAULT,0,num,&nf,wout,96)>0)
        WideCharToMultiByte(CP_UTF8,0,wout,-1,out,(int)cap,NULL,NULL);
    else
        snprintf(out,cap,"%s",cnum);
}
static void fmt_u64_grouped(unsigned long long n, char *out, size_t cap){
    char a[32]; snprintf(a,sizeof(a),"%llu",n); numfmt_locale(a,0,out,cap);
}
static void fmt_double_locale(double v, int digits, char *out, size_t cap){
    char a[48]; snprintf(a,sizeof(a),"%.*f",digits,v); numfmt_locale(a,digits,out,cap);
}
static void fmt_bytes(unsigned long long n, char *out, size_t cap){
    static const char *u[]={"bytes","KB","MB","GB","TB"};
    double v=(double)n; int idx=0; char g[40];
    while(v>=1024.0 && idx<4){ v/=1024.0; idx++; }
    fmt_u64_grouped(n,g,sizeof(g));
    if(idx==0) snprintf(out,cap,"%s bytes",g);
    else { char val[48]; fmt_double_locale(v,2,val,sizeof(val)); snprintf(out,cap,"%s %s (%s bytes)",val,u[idx],g); }
}
/* Absolute device path: the com.apple.afc jail root is /var/mobile/Media, so prefixing makes
 * paths match what a jailbroken full-filesystem (com.apple.afc2) view would show for the same item. */
static void abs_devpath(const char *afc, char *out, size_t cap){
    if(strcmp(afc,"/")==0) snprintf(out,cap,"/var/mobile/Media");
    else                   snprintf(out,cap,"/var/mobile/Media%s",afc);
}
static void fmt_afctime(const char *nsdec, char *out, size_t cap){
    unsigned long long ns; FILETIME ft,lft; SYSTEMTIME st;
    if(!nsdec || !*nsdec){ snprintf(out,cap,"(n/a)"); return; }
    ns=strtoull(nsdec,NULL,10); ns_to_filetime(ns,&ft);
    if(!FileTimeToLocalFileTime(&ft,&lft) || !FileTimeToSystemTime(&lft,&st)){ snprintf(out,cap,"(n/a)"); return; }
    snprintf(out,cap,"%04d-%02d-%02d  %02d:%02d:%02d",st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond);
}

static const char *ifmt_name(const char *v){
    if(!strcmp(v,"S_IFREG"))  return "Regular file";
    if(!strcmp(v,"S_IFDIR"))  return "Folder";
    if(!strcmp(v,"S_IFLNK"))  return "Symbolic link";
    if(!strcmp(v,"S_IFBLK"))  return "Block device";
    if(!strcmp(v,"S_IFCHR"))  return "Character device";
    if(!strcmp(v,"S_IFIFO"))  return "FIFO (pipe)";
    if(!strcmp(v,"S_IFSOCK")) return "Socket";
    return v;
}

#define PB(...) do{ if((size_t)off<cap) off+=snprintf(buf+off,cap-off,__VA_ARGS__); }while(0)

static void build_device_props(char *buf, size_t cap){
    int off=0; char b1[64],b2[64],b3[64];
    PB("Apple Mobile Device\r\n-------------------\r\n\r\n");
    /* A persistent socket can be stale after a cable pull while g_s.connected is still
       set; probe the link (bounded wait so a half-open socket can't hang the dialog) and
       refresh free space. On failure drop it so the reconnect below runs and, if the cable
       is still out, surfaces the diagnostic chain instead of stale cached values. */
    if(g_s.connected){
        DWORD tmo=3000, old=0; int ol=(int)sizeof(old);
        getsockopt(g_s.sock,SOL_SOCKET,SO_RCVTIMEO,(char*)&old,&ol);
        setsockopt(g_s.sock,SOL_SOCKET,SO_RCVTIMEO,(char*)&tmo,sizeof(tmo));
        if(afc_query_devinfo()!=0) afc_disconnect_session();
        else setsockopt(g_s.sock,SOL_SOCKET,SO_RCVTIMEO,(char*)&old,sizeof(old));
    }
    if(!g_s.connected && afc_connect_session()!=0){
        PB("Status:           NOT CONNECTED\r\n\r\n");
        PB("The plugin could not establish a connection. Diagnostic:\r\n\r\n  %s\r\n",
           g_s.last_error[0]?g_s.last_error:"(no detail captured)");
        PB("\r\nThe connection runs through Apple Mobile Device Service over USB:\r\n");
        PB("usbmux -> lockdown -> TLS session -> StartService(com.apple.afc).\r\n");
        return;
    }
    PB("Status:           Connected\r\n");
    PB("Connection:       %s\r\n\r\n", g_s.conn_type);
    PB("-- Device --\r\n");
    PB("Model:            %s\r\n", g_s.model[0]?g_s.model:"(unknown)");
    PB("iOS version:      %s\r\n", g_s.ios_version[0]?g_s.ios_version:"(unknown)");
    PB("UDID:             %s\r\n\r\n", g_s.udid[0]?g_s.udid:"(unknown)");
    PB("-- AFC service --\r\n");
    PB("Daemon version:   %s\r\n", g_s.afc_version[0]?g_s.afc_version:"(unknown)");
    PB("Jail root:        /var/mobile/Media  (com.apple.afc)\r\n\r\n");
    PB("-- Storage --\r\n");
    fmt_bytes(g_s.fs_total,b1,sizeof(b1));
    fmt_bytes(g_s.fs_total>=g_s.fs_free?g_s.fs_total-g_s.fs_free:0,b3,sizeof(b3));
    fmt_bytes(g_s.fs_free,b2,sizeof(b2));
    PB("Capacity:         %s\r\n", b1);
    PB("Used:             %s\r\n", b3);
    PB("Free:             %s\r\n", b2);
    { char gb[40]; fmt_u64_grouped((unsigned long long)g_s.fs_block,gb,sizeof(gb)); PB("Block size:       %s bytes\r\n\r\n", gb); }
    PB("-- Secure channel --\r\n");
    PB("lockdown TLS:     %s\r\n", g_s.tls_info[0]?g_s.tls_info:"(unknown)");
}
static void build_file_props(const char *afc, char *buf, size_t cap){
    int off=0; unsigned char *blob=NULL; int bl=0; char v[96], t[64], b1[64];
    const char *name=strrchr(afc,'/'); name=(name&&name[1])?name+1:afc;
    PB("%s\r\nFile\r\n\r\n", name);
    { char ap[AFC_PATHMAX]; abs_devpath(afc,ap,sizeof(ap)); PB("Full path:        %s\r\n", ap); }
    if(afc_get_file_info(g_s.sock,afc,&g_s.pkt,&blob,&bl)!=0){ PB("\r\n(could not read file information)\r\n"); return; }
    if(afc_kv_lookup(blob,bl,"st_size",v,sizeof(v))==0){ fmt_bytes(strtoull(v,NULL,10),b1,sizeof(b1)); PB("Size:             %s\r\n", b1); }
    if(afc_kv_lookup(blob,bl,"st_blocks",v,sizeof(v))==0){ char g[40]; fmt_u64_grouped(strtoull(v,NULL,10),g,sizeof(g)); PB("Blocks:           %s\r\n", g); }
    if(afc_kv_lookup(blob,bl,"st_nlink",v,sizeof(v))==0){ char g[40]; fmt_u64_grouped(strtoull(v,NULL,10),g,sizeof(g)); PB("Hard links:       %s\r\n", g); }
    if(afc_kv_lookup(blob,bl,"st_ifmt",v,sizeof(v))==0)   PB("Type:             %s\r\n", ifmt_name(v));
    if(afc_kv_lookup(blob,bl,"st_mtime",v,sizeof(v))==0){ fmt_afctime(v,t,sizeof(t)); PB("Modified:         %s\r\n", t); }
    if(afc_kv_lookup(blob,bl,"st_birthtime",v,sizeof(v))==0){ fmt_afctime(v,t,sizeof(t)); PB("Created:          %s\r\n", t); }
    if(afc_kv_lookup(blob,bl,"LinkTarget",v,sizeof(v))==0) PB("Link target:      %s\r\n", v);
    free(blob);
    PB("\r\n-- Device-side SHA-1 --\r\n");
    { unsigned char h[20]; char hx[41]; int i;
      if(afc_file_sha1(afc,h)==0){ for(i=0;i<20;i++) snprintf(hx+i*2,3,"%02x",h[i]); PB("%s\r\n", hx); }
      else PB("(unavailable)\r\n"); }
}
static void build_dir_props(const char *afc, char *buf, size_t cap){
    int off=0; unsigned char *blob=NULL; int bl=0; char v[96], t[64], b1[64];
    unsigned long long bytes=0, files=0, dirs=0;
    const char *name=strrchr(afc,'/'); name=(name&&name[1])?name+1:afc;
    PB("%s\r\nFolder\r\n\r\n", (strcmp(afc,"/")==0)?"/  (Media)":name);
    { char ap[AFC_PATHMAX]; abs_devpath(afc,ap,sizeof(ap)); PB("Full path:        %s\r\n", ap); }
    if(afc_get_file_info(g_s.sock,afc,&g_s.pkt,&blob,&bl)==0){
        if(afc_kv_lookup(blob,bl,"st_nlink",v,sizeof(v))==0){ char g[40]; fmt_u64_grouped(strtoull(v,NULL,10),g,sizeof(g)); PB("Hard links:       %s\r\n", g); }
        if(afc_kv_lookup(blob,bl,"st_mtime",v,sizeof(v))==0){ fmt_afctime(v,t,sizeof(t)); PB("Modified:         %s\r\n", t); }
        if(afc_kv_lookup(blob,bl,"st_birthtime",v,sizeof(v))==0){ fmt_afctime(v,t,sizeof(t)); PB("Created:          %s\r\n", t); }
        free(blob);
    }
    PB("\r\n-- Contents (recursive) --\r\n");
    afc_tree_size(afc,&bytes,&files,&dirs,0);
    fmt_bytes(bytes,b1,sizeof(b1));
    { char gf[40],gd[40]; fmt_u64_grouped(files,gf,sizeof(gf)); fmt_u64_grouped(dirs,gd,sizeof(gd));
      PB("Total size:       %s\r\n", b1);
      PB("Files:            %s\r\n", gf);
      PB("Sub-folders:      %s\r\n", gd); }
}
#undef PB

typedef struct { const WCHAR *title; const WCHAR *text; } prop_dlg_t;
static HFONT g_prop_font=NULL;

static void clip_set_text(HWND owner, const WCHAR *s){
    size_t n=(wcslen(s)+1)*sizeof(WCHAR); HGLOBAL h; void *p;
    if(!OpenClipboard(owner)) return;
    EmptyClipboard();
    h=GlobalAlloc(GMEM_MOVEABLE,n);
    if(h){ p=GlobalLock(h); if(p){ memcpy(p,s,n); GlobalUnlock(h); SetClipboardData(CF_UNICODETEXT,h); } }
    CloseClipboard();
}
static INT_PTR CALLBACK PropDlgProc(HWND dlg, UINT msg, WPARAM wp, LPARAM lp){
    switch(msg){
        case WM_INITDIALOG:{
            prop_dlg_t *pd=(prop_dlg_t*)lp;
            SetWindowLongPtrW(dlg,GWLP_USERDATA,(LONG_PTR)pd);
            if(pd){ SetWindowTextW(dlg,pd->title); SetDlgItemTextW(dlg,IDC_PROP_EDIT,pd->text); }
            if(!g_prop_font) g_prop_font=CreateFontW(-12,0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,
                OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,FIXED_PITCH|FF_MODERN,L"Lucida Console");
            SendDlgItemMessageW(dlg,IDC_PROP_EDIT,WM_SETFONT,(WPARAM)g_prop_font,TRUE);
            SendDlgItemMessageW(dlg,IDC_PROP_EDIT,EM_SETSEL,(WPARAM)-1,0);
            return TRUE;
        }
        case WM_COMMAND:
            switch(LOWORD(wp)){
                case IDOK: case IDCANCEL: EndDialog(dlg,LOWORD(wp)); return TRUE;
                case IDC_PROP_COPY:{
                    prop_dlg_t *pd=(prop_dlg_t*)GetWindowLongPtrW(dlg,GWLP_USERDATA);
                    if(pd) clip_set_text(dlg,pd->text);
                    return TRUE;
                }
            }
            break;
    }
    return FALSE;
}
static void show_props_dialog(HWND parent, const WCHAR *title, const char *utf8){
    int wn; WCHAR *wbuf; prop_dlg_t pd;
    wn=MultiByteToWideChar(CP_UTF8,0,utf8,-1,NULL,0); if(wn<=0) return;
    wbuf=(WCHAR*)malloc((size_t)wn*sizeof(WCHAR)); if(!wbuf) return;
    MultiByteToWideChar(CP_UTF8,0,utf8,-1,wbuf,wn);
    pd.title=title; pd.text=wbuf;
    DialogBoxParamW(g_hinst,MAKEINTRESOURCEW(IDD_PROPS),parent,PropDlgProc,(LPARAM)&pd);
    free(wbuf);
}

int __stdcall FsExecuteFileW(HWND MainWin, WCHAR* RemoteName, WCHAR* Verb){
    char afc[AFC_PATHMAX], synth[256]; int kind; char *buf;
    DBG("[AppleAFC] ExecuteFile path=\"%ls\" verb=\"%ls\"", RemoteName, Verb);
    if(_wcsicmp(Verb,L"properties")!=0) return FS_EXEC_YOURSELF;   /* open -> TC downloads+runs; others n/a */

    kind=tc_classify(RemoteName,synth,sizeof(synth),afc,sizeof(afc));
    buf=(char*)malloc(65536); if(!buf) return FS_EXEC_OK;

    if(kind==0 || (kind==1 && strcmp(afc,"/")==0)){               /* root / synthetic -> device sheet */
        build_device_props(buf,65536);
        show_props_dialog(MainWin,L"Apple AFC \x2014 Device properties",buf);
    } else if(kind==1){
        unsigned char *blob=NULL; int bl=0; char v[32]; int isdir=0;
        if(!g_s.connected && afc_connect_session()!=0){
            free(buf); MessageBoxW(MainWin,L"Could not connect to the device.",L"Apple AFC",MB_OK|MB_ICONWARNING);
            return FS_EXEC_OK;
        }
        if(afc_get_file_info(g_s.sock,afc,&g_s.pkt,&blob,&bl)==0){
            isdir=(afc_kv_lookup(blob,bl,"st_ifmt",v,sizeof(v))==0 && !strcmp(v,"S_IFDIR")); free(blob);
        }
        if(isdir){ build_dir_props(afc,buf,65536);  show_props_dialog(MainWin,L"Apple AFC \x2014 Folder properties",buf); }
        else     { build_file_props(afc,buf,65536); show_props_dialog(MainWin,L"Apple AFC \x2014 File properties",buf); }
    }
    free(buf);
    return FS_EXEC_OK;
}
int __stdcall FsExecuteFile(HWND MainWin, char* RemoteName, char* Verb){
    WCHAR wr[AFC_PATHMAX], wv[64];
    MultiByteToWideChar(CP_ACP,0,RemoteName,-1,wr,AFC_PATHMAX);
    MultiByteToWideChar(CP_ACP,0,Verb,-1,wv,64);
    return FsExecuteFileW(MainWin,wr,wv);
}

BOOL WINAPI DllMain(HINSTANCE hinst, DWORD reason, LPVOID reserved){
    (void)reserved;
    if(reason==DLL_PROCESS_ATTACH){ g_hinst=hinst; DisableThreadLibraryCalls(hinst); }
    else if(reason==DLL_PROCESS_DETACH){ afc_disconnect_session(); if(g_prop_font){ DeleteObject(g_prop_font); g_prop_font=NULL; } }
    return TRUE;
}
