/* ios_domains.h -- iOS backup domain -> on-device root-path resolver,
 * driven by an external, user-editable mapping file.
 *
 * An iOS backup never stores a fully-qualified path. Manifest.db's Files table
 * stores a (domain, relativePath) pair, and the device path is
 *
 *      RootPath(domain) + "/" + relativePath
 *
 * The RootPath of each domain is not itself stored in the backup, so the mapping
 * has to be supplied. Rather than compile it into the plugin, the table is read
 * at run time from a plain-text file
 *
 *      ios_domains.cfg      (in the same folder as the plugin .wcx / .wfx)
 *
 * so it can be read and corrected in any text editor without rebuilding. If the
 * file is missing or has no usable rules, the plugin says so once and then lists
 * every entry under its stored "Domain\relativePath" name, unconverted -- nothing
 * is invented. If the file is present but a domain in the backup has no rule, the
 * plugin warns once that some domains could not be resolved.
 *
 * ------------------------------ FILE FORMAT --------------------------------
 *   Domain = /device/path                      one rule per line
 *   - the FIRST '=' splits domain from path, so a path may contain spaces
 *     (e.g.  ManagedPreferencesDomain = /var/Managed Preferences).
 *   - a domain whose name ends in '-' is a PREFIX rule: whatever follows the '-'
 *     in the real domain is appended as one path segment, e.g.
 *         AppDomain- = /var/mobile/Containers/Data/Application
 *     maps  AppDomain-com.foo.Bar  ->  .../Data/Application/com.foo.Bar
 *   - a path of a single '-' means the domain is KNOWN but intentionally shown
 *     as stored (no conversion, and no "unresolved" warning) -- e.g. BackupDomain.
 *   - lines starting with '#' or ';' are comments; blank lines are ignored.
 *   - write paths with '/'; the caller converts to '\' for display.
 *
 * This header is CODE ONLY -- the data lives in ios_domains.cfg. It keeps
 * file-scope (static) state, so it must be #included in EXACTLY ONE translation
 * unit per plugin DLL (here: manifest_core.c). A second plugin is a separate DLL
 * and gets its own copy, which is fine. man_log() (manifest_core.h) is used for
 * diagnostics; it is compiled to a no-op unless MANIFESTDB_DEBUG is defined, but
 * the warning message boxes are shown either way.
 *
 * A successful load is cached for the life of the process; a failed load is
 * retried on the next lookup, so creating the file and re-opening a *different*
 * archive picks it up without restarting Total Commander. Editing an already
 * loaded file takes effect on the next restart. Each warning is shown once.
 */
#ifndef IOS_DOMAINS_H
#define IOS_DOMAINS_H

#include <string.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#ifdef _WIN32
#include <windows.h>
#include <wchar.h>
#endif

#define IOS_DOMAINS_FILE    "ios_domains.cfg"
#ifdef _WIN32
#define IOS_DOMAINS_FILE_W  L"ios_domains.cfg"
#endif

typedef struct { char *domain; char *root;   } ios_fixed_rule;   /* exact match   */
typedef struct { char *prefix; char *parent; } ios_prefix_rule;  /* "<prefix>-..." */

static ios_fixed_rule  *g_ios_fixed = NULL;  static int g_ios_nfixed = 0;
static ios_prefix_rule *g_ios_pre   = NULL;  static int g_ios_npre   = 0;
static int g_ios_ok = 0;     /* 1 once a usable table has been installed */

/* one-shot latches for the user-facing warnings (independent of each other) */
static volatile long g_ios_warn_missing = 0;   /* file absent / unreadable / empty */
static volatile long g_ios_warn_partial = 0;   /* file ok but a domain was unmapped */

/* distinct unmapped domains, logged once each (best-effort, bounded) */
static char *g_ios_unres[64];
static volatile long g_ios_nunres = 0;

/* trim leading/trailing blanks (and CR/LF) in place; returns start of content */
static char *ios_trim(char *s){
    char *e;
    while(*s==' '||*s=='\t') s++;
    e = s + strlen(s);
    while(e>s && (e[-1]==' '||e[-1]=='\t'||e[-1]=='\r'||e[-1]=='\n')) *--e = 0;
    return s;
}

static int ios_push_fixed(ios_fixed_rule **a,int *n,int *cap,const char *d,const char *r){
    if(*n==*cap){ int nc=*cap?*cap*2:8; void *p=realloc(*a,nc*sizeof(**a)); if(!p)return 0; *a=p; *cap=nc; }
    (*a)[*n].domain=strdup(d); (*a)[*n].root=strdup(r);
    if(!(*a)[*n].domain||!(*a)[*n].root) return 0;
    (*n)++; return 1;
}
static int ios_push_pre(ios_prefix_rule **a,int *n,int *cap,const char *p_,const char *par){
    if(*n==*cap){ int nc=*cap?*cap*2:8; void *p=realloc(*a,nc*sizeof(**a)); if(!p)return 0; *a=p; *cap=nc; }
    (*a)[*n].prefix=strdup(p_); (*a)[*n].parent=strdup(par);
    if(!(*a)[*n].prefix||!(*a)[*n].parent) return 0;
    (*n)++; return 1;
}

/* fire a latched warning at most once: one (debug) log line, and on Windows one
   message box. boxmsg is ignored off Windows (may be NULL). */
static int ios_latch_fire(volatile long *latch){
#ifdef _WIN32
    return InterlockedCompareExchange(latch,1,0)==0;
#else
    if(*latch) return 0; *latch=1; return 1;
#endif
}
static void ios_warn_once(volatile long *latch, const char *logmsg, const wchar_t *boxmsg){
    if(!ios_latch_fire(latch)) return;
    man_log("%s", logmsg);
#ifdef _WIN32
    if(boxmsg) MessageBoxW(NULL,boxmsg,L"ManifestDB plugin",MB_OK|MB_ICONWARNING|MB_SETFOREGROUND);
#else
    (void)boxmsg;
#endif
}

/* record that 'domain' (present in the backup) had no rule in the loaded file:
   raise the one-time popup, and log each distinct domain once so it can be added. */
static void ios_note_unresolved(const char *domain){
    long i, n;
    ios_warn_once(&g_ios_warn_partial,
        "ios_domains: backup contains domain(s) not defined in cfg; shown as stored",
        L"Backup contains internal domains not defined in ios_domains.cfg file.\n"
        L"Those domains will not be resolved to actual paths.");
    n = g_ios_nunres;
    for(i=0;i<n && i<64;i++) if(g_ios_unres[i] && strcmp(g_ios_unres[i],domain)==0) return;
#ifdef _WIN32
    { long idx = InterlockedIncrement(&g_ios_nunres) - 1;
      if(idx<64){ g_ios_unres[idx]=strdup(domain);
                  man_log("ios_domains: domain '%s' not defined in %s; shown as stored", domain, IOS_DOMAINS_FILE); } }
#else
    { long idx = g_ios_nunres++;
      if(idx<64){ g_ios_unres[idx]=strdup(domain);
                  man_log("ios_domains: domain '%s' not defined in %s; shown as stored", domain, IOS_DOMAINS_FILE); } }
#endif
}

#ifdef _WIN32
/* UTF-8 rendering of a wide string, for man_log()/messages */
static void ios_w2utf8(const wchar_t *w,char *out,int cap){
    if(WideCharToMultiByte(CP_UTF8,0,w,-1,out,cap,NULL,NULL)==0 && cap>0) out[0]=0;
}
/* Directory of THIS plugin DLL, wide, no trailing slash. Resolved from the
   address of one of our own statics, so it is the DLL's path, not totalcmd.exe's. */
static int ios_self_dir_w(wchar_t *out,int cap){
    HMODULE h=NULL; wchar_t path[1024]; DWORD n; wchar_t *s,*s2;
    if(!GetModuleHandleExW(
            GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
            (LPCWSTR)(void*)&g_ios_ok, &h)) return 0;
    n=GetModuleFileNameW(h,path,(DWORD)(sizeof(path)/sizeof(path[0])));
    if(n==0 || n>=sizeof(path)/sizeof(path[0])) return 0;
    s=wcsrchr(path,L'\\'); s2=wcsrchr(path,L'/'); if(s2 && (!s||s2>s)) s=s2;
    if(!s) return 0;
    *s=0; _snwprintf(out,cap,L"%s",path); out[cap-1]=0; return 1;
}
#endif

/* Parse ios_domains.cfg and, only on success, install it into the globals.
   On any failure it installs nothing and leaves g_ios_ok = 0 (caller shows raw). */
static void ios_load_now(void){
#ifdef _WIN32
    wchar_t dir[1024], full[1280]; char u8full[2048];
    FILE *f; char line[4096];
    ios_fixed_rule  *F=NULL; int nf=0, cf=0;
    ios_prefix_rule *P=NULL; int np=0, cp=0;
    int lineno=0, skipped=0;

    if(!ios_self_dir_w(dir,1024)){
        ios_warn_once(&g_ios_warn_missing,
            "ios_domains: cannot locate plugin folder; domains shown as stored",
            L"Could not locate the plugin folder to find ios_domains.cfg.\n"
            L"Internal backup domains will not be resolved to actual paths.");
        return;
    }
    _snwprintf(full,1280,L"%s\\%s",dir,IOS_DOMAINS_FILE_W); full[1279]=0;
    ios_w2utf8(full,u8full,sizeof(u8full));

    f=_wfopen(full,L"rb");
    if(!f){
        char log[2200];
        _snprintf(log,sizeof(log),"ios_domains: '%s' not found; domains shown as stored",u8full); log[sizeof(log)-1]=0;
        ios_warn_once(&g_ios_warn_missing, log,
            L"File ios_domains.cfg is not found in the plugin directory.\n"
            L"Internal backup domains will not be resolved to actual paths.");
        return;
    }

    while(fgets(line,sizeof(line),f)){
        char *s,*eq,*key,*val; size_t klen; int ok;
        lineno++;
        s=ios_trim(line);
        if(*s==0||*s=='#'||*s==';') continue;
        eq=strchr(s,'=');
        if(!eq){ man_log("ios_domains: line %d ignored (no '='): %s", lineno, s); skipped++; continue; }
        *eq=0; key=ios_trim(s); val=ios_trim(eq+1);
        if(*key==0||*val==0){ man_log("ios_domains: line %d ignored (empty key or value)", lineno); skipped++; continue; }
        klen=strlen(key);
        ok = (key[klen-1]=='-') ? ios_push_pre(&P,&np,&cp,key,val)
                                : ios_push_fixed(&F,&nf,&cf,key,val);
        if(!ok){ man_log("ios_domains: out of memory at line %d", lineno); fclose(f); free(F); free(P); return; }
    }
    fclose(f);

    if(nf+np==0){
        char log[2200];
        _snprintf(log,sizeof(log),"ios_domains: '%s' had no usable rules (%d line(s) skipped); domains shown as stored",u8full,skipped); log[sizeof(log)-1]=0;
        ios_warn_once(&g_ios_warn_missing, log,
            L"File ios_domains.cfg contains no valid definitions.\n"
            L"Internal backup domains will not be resolved to actual paths.");
        free(F); free(P); return;
    }

    g_ios_fixed=F; g_ios_nfixed=nf; g_ios_pre=P; g_ios_npre=np; g_ios_ok=1;
    man_log("ios_domains: loaded %d exact + %d prefix rule(s) from %s (%d line(s) skipped)",
            nf, np, u8full, skipped);
#else
    /* non-Windows test harness: read ios_domains.cfg from the current directory */
    FILE *f=fopen(IOS_DOMAINS_FILE,"rb"); char line[4096];
    ios_fixed_rule  *F=NULL; int nf=0, cf=0;
    ios_prefix_rule *P=NULL; int np=0, cp=0;
    if(!f){ ios_warn_once(&g_ios_warn_missing, "ios_domains: 'ios_domains.cfg' not found (cwd); domains shown as stored", NULL); return; }
    while(fgets(line,sizeof(line),f)){
        char *s=ios_trim(line),*eq,*key,*val;
        if(*s==0||*s=='#'||*s==';') continue;
        eq=strchr(s,'='); if(!eq) continue; *eq=0;
        key=ios_trim(s); val=ios_trim(eq+1);
        if(*key==0||*val==0) continue;
        if(key[strlen(key)-1]=='-') ios_push_pre(&P,&np,&cp,key,val);
        else                        ios_push_fixed(&F,&nf,&cf,key,val);
    }
    fclose(f);
    if(nf+np==0){ ios_warn_once(&g_ios_warn_missing, "ios_domains: 'ios_domains.cfg' had no usable rules; domains shown as stored", NULL); free(F); free(P); return; }
    g_ios_fixed=F; g_ios_nfixed=nf; g_ios_pre=P; g_ios_npre=np; g_ios_ok=1;
    man_log("ios_domains: loaded %d exact + %d prefix rule(s)", nf, np);
#endif
}

/* Ensure the table is loaded. A good table is loaded at most once; a failed
   attempt is retried on the next call (cheap), so creating the file and opening
   a different archive picks it up without restarting Total Commander. */
static void ios_ensure_loaded(void){
    if(g_ios_ok) return;
#ifdef _WIN32
    {
        static volatile LONG busy=0;
        if(InterlockedCompareExchange(&busy,1,0)!=0){ while(busy) Sleep(0); return; }
        if(!g_ios_ok) ios_load_now();
        InterlockedExchange(&busy,0);
    }
#else
    ios_load_now();
#endif
}

/* Resolve a domain to its on-device root path (POSIX, leading '/').
   Returns 1 and writes the root into out on success; 0 if the domain is unknown,
   declared unmapped ('-'), or no table is loaded -- in those cases the caller
   keeps the stored "Domain\relativePath". A genuinely unknown domain (table
   loaded, no rule, not declared '-') also raises the one-time "unresolved" warning. */
static int ios_domain_root(const char *domain, char *out, size_t cap){
    int i, best=-1; size_t bestlen=0;
    if(!domain || !*domain || cap==0){ if(cap) out[0]=0; return 0; }
    ios_ensure_loaded();
    if(!g_ios_ok){ out[0]=0; return 0; }   /* no table: handled by missing-file warning */

    for(i=0;i<g_ios_nfixed;i++)
        if(strcmp(domain,g_ios_fixed[i].domain)==0){
            const char *r=g_ios_fixed[i].root;
            if(r[0]=='-' && r[1]==0){ out[0]=0; return 0; }   /* declared unmapped: raw, no warning */
            snprintf(out,cap,"%s",r); return 1;
        }

    /* longest matching prefix wins, so overlapping prefixes stay unambiguous */
    for(i=0;i<g_ios_npre;i++){
        size_t plen=strlen(g_ios_pre[i].prefix);
        if(strncmp(domain,g_ios_pre[i].prefix,plen)==0 && plen>bestlen){ bestlen=plen; best=i; }
    }
    if(best>=0){
        const char *token=domain+bestlen;       /* may be "" if domain ends '-' */
        if(*token){
            char tok[256]; size_t j=0; const char *t;
            for(t=token; *t && j+1<sizeof(tok); t++)
                tok[j++]=(*t=='/'||*t=='\\')?'_':*t;
            tok[j]=0;
            snprintf(out,cap,"%s/%s",g_ios_pre[best].parent,tok);
        } else {
            snprintf(out,cap,"%s",g_ios_pre[best].parent);
        }
        return 1;
    }

    ios_note_unresolved(domain);   /* table loaded, domain genuinely unknown */
    out[0]=0; return 0;
}

#endif /* IOS_DOMAINS_H */
