/* manifest_core.c -- iOS backup Manifest.db parser/resolver. See manifest_core.h.
 *
 * The Files table IS the directory listing, so the only disk access is confirming
 * each file's hash-named blob is present. Per-file timestamps and size come from
 * each row's NSKeyedArchiver `file` metadata blob (a small binary plist), parsed
 * below. File names are kept as UTF-8 and all path access goes through the wide
 * Win32 APIs on Windows, so any-language paths and the deep system paths that
 * exceed the legacy limit work; the SHA-1 hash sub-paths are ASCII regardless.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>
#include <sys/stat.h>
#ifdef _WIN32
#include <windows.h>
#include <wchar.h>
#endif
#include <sqlite3.h>
#include "manifest_core.h"
#include "ios_domains.h"   /* shared domain -> device-root-path resolver */

/* ----------------------------- debug logging ------------------------------ */
void man_log(const char *fmt, ...){
    FILE *f = fopen("C:\\manifestdb_wcx.log", "a");
    if(!f) return;
    va_list ap; va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fputc('\n', f);
    fclose(f);
}

/* ------------------------ unicode-safe file access ------------------------ */
/* Open a file read-only by UTF-8 path (wide on Windows so non-ASCII paths work). */
static FILE* open_ro_utf8(const char *path){
#ifdef _WIN32
    wchar_t w[4096];
    if(MultiByteToWideChar(CP_UTF8,0,path,-1,w,4096)==0) return NULL;
    return _wfopen(w, L"rb");
#else
    return fopen(path,"rb");
#endif
}
/* 1 if a regular file exists at UTF-8 path. */
static int regular_file_exists(const char *path){
#ifdef _WIN32
    wchar_t w[4096];
    if(MultiByteToWideChar(CP_UTF8,0,path,-1,w,4096)==0) return 0;
    DWORD a=GetFileAttributesW(w);
    return (a!=INVALID_FILE_ATTRIBUTES && !(a&FILE_ATTRIBUTE_DIRECTORY));
#else
    struct stat st; return (stat(path,&st)==0 && S_ISREG(st.st_mode));
#endif
}

/* ----------------------------- path helpers ------------------------------- */
/* Sanitise one path component: characters Windows forbids in a name (and our '\'
   separator) become '_'; trailing dots/spaces trimmed; empty result -> "_". */
static void sanitise(const char *in, char *out, size_t cap){
    size_t j=0; const char *p;
    for(p=in; *p && j+1<cap; p++){
        unsigned char c=(unsigned char)*p;
        if(c<32 || c=='<'||c=='>'||c==':'||c=='"'||c=='/'||c=='\\'||c=='|'||c=='?'||c=='*')
            out[j++]='_';
        else
            out[j++]=(char)c;
    }
    out[j]=0;
    while(j>0 && (out[j-1]=='.'||out[j-1]==' ')) out[--j]=0;
    if(j==0){ out[0]='_'; out[1]=0; }
}
/* Build the entry's display name as its ACTUAL device path, backslash-separated
   and each component sanitised, with no leading separator (so the top folder is
   e.g. "var", which TC shows directly; a leading "\" would make an empty root).

   The domain is resolved to its real device root via ios_domain_root(); the
   relativePath is appended under it. So (CameraRollDomain, "Media/DCIM/x.JPG")
   becomes "var\mobile\Media\DCIM\x.JPG" -- byte-for-byte what the AFC view shows
   for the same file. An unresolved domain keeps its own name as the top folder
   (e.g. "BackupDomain\..."), which is honest about what we can't place. */
static void build_name(const char *domain, const char *rel, char *out, size_t cap){
    char root[1024];
    char full[4096];

    if(ios_domain_root(domain, root, sizeof(root))){
        if(rel && *rel) snprintf(full, sizeof(full), "%s/%s", root, rel);
        else            snprintf(full, sizeof(full), "%s", root);
    } else {
        const char *d = (domain && *domain) ? domain : "_nodomain";
        if(rel && *rel) snprintf(full, sizeof(full), "%s/%s", d, rel);
        else            snprintf(full, sizeof(full), "%s", d);
    }

    /* Split 'full' on '/', drop empty / "." / ".." segments, sanitise each, and
       join with '\'. The leading '/' of a resolved root yields an empty first
       segment that is skipped, so there is no leading backslash. */
    size_t n=0; out[0]=0;
    const char *p=full;
    while(*p){
        const char *q=p; while(*q && *q!='/') q++;
        size_t len=(size_t)(q-p);
        if(!(len==0 || (len==1&&p[0]=='.') || (len==2&&p[0]=='.'&&p[1]=='.'))){
            char part[512]; size_t L=len; if(L>=sizeof(part)) L=sizeof(part)-1;
            memcpy(part,p,L); part[L]=0;
            char comp[512]; sanitise(part, comp, sizeof(comp));
            if(n==0)        n += (size_t)snprintf(out+n, cap, "%s", comp);
            else if(n<cap)  n += (size_t)snprintf(out+n, cap-n, "\\%s", comp);
        }
        p = (*q=='/') ? q+1 : q;
    }
    if(n==0){ out[0]='_'; out[1]=0; }   /* everything stripped -> safe fallback */
}
/* Directory holding Manifest.db -> the backup root (where the hash dirs live). */
static void backup_root_of(const char *manifest, char *out, size_t cap){
    strncpy(out, manifest, cap-1); out[cap-1]=0;
    char *slash=strrchr(out,'/');
    char *bs=strrchr(out,'\\'); if(bs && (!slash || bs>slash)) slash=bs;
    if(slash) *slash=0; else strcpy(out,".");
}
/* On-disk blob for a fileID: <root>/<id[:2]>/<id>, else flat <root>/<id>.
   Returns 1 and fills *out (UTF-8) if a regular file is present. */
static int blob_exists(const char *root, const char *fid, char *out, size_t cap){
    snprintf(out,cap,"%s/%c%c/%s", root, fid[0], fid[1], fid);
    if(regular_file_exists(out)) return 1;
    snprintf(out,cap,"%s/%s", root, fid);
    if(regular_file_exists(out)) return 1;
    return 0;
}

/* -------------------- minimal binary-plist (metadata) --------------------- */
/* Read top-level integer fields (Birth, LastModified, Size) from the root dict of
   an NSKeyedArchiver MBFile bplist. Only the object kinds we meet are handled:
   dict (root), ASCII string keys, and integers. Fully bounds-checked. */
static unsigned long long be_read(const unsigned char *p, int n){
    unsigned long long v=0; int i; for(i=0;i<n;i++) v=(v<<8)|p[i]; return v;
}
typedef struct { const unsigned char *b; size_t len; int osz, rsz; unsigned long long nobj, toff; } bpl;

static unsigned long long bpl_obj_off(const bpl *c, unsigned long long idx){
    if(idx>=c->nobj) return 0;
    unsigned long long pos = c->toff + idx*(unsigned long long)c->osz;
    if(pos + (unsigned long long)c->osz > c->len) return 0;
    return be_read(c->b+pos, c->osz);
}
static int bpl_int_at(const bpl *c, unsigned long long off, long long *out){
    if(off>=c->len) return 0;
    unsigned char m=c->b[off];
    if((m&0xF0)!=0x10) return 0;
    int nb = 1 << (m&0x0F);
    if(off+1+(unsigned long long)nb > c->len) return 0;
    if(nb<=8) *out=(long long)be_read(c->b+off+1, nb);
    else      *out=(long long)be_read(c->b+off+1+nb-8, 8);   /* low 64 bits */
    return 1;
}
static int bpl_str_eq(const bpl *c, unsigned long long off, const char *key){
    if(off>=c->len) return 0;
    unsigned char m=c->b[off];
    if((m&0xF0)!=0x50) return 0;                              /* ASCII string */
    unsigned long long n=m&0x0F, p=off+1;
    if(n==0x0F){
        if(p>=c->len) return 0; unsigned char im=c->b[p]; if((im&0xF0)!=0x10) return 0;
        int ib=1<<(im&0x0F); if(p+1+(unsigned long long)ib>c->len) return 0;
        n=be_read(c->b+p+1,ib); p+=1+ib;
    }
    if(p+n>c->len) return 0;
    size_t kl=strlen(key);
    return (n==kl) && memcmp(c->b+p,key,kl)==0;
}
/* Pull Birth/LastModified/Size out of a candidate dict at byte offset 'off'.
   Returns how many of the three keys were found here. */
static int dict_extract(const bpl *c, unsigned long long off,
                        long long *birth, long long *modi, long long *size){
    const unsigned char *b=c->b; size_t len=c->len;
    unsigned char m=b[off];
    if((m&0xF0)!=0xD0) return 0;
    unsigned long long n=m&0x0F, p=off+1;
    if(n==0x0F){
        if(p>=len) return 0; unsigned char im=b[p]; if((im&0xF0)!=0x10) return 0;
        int ib=1<<(im&0x0F); if(p+1+(unsigned long long)ib>len) return 0;
        n=be_read(b+p+1,ib); p+=1+ib;
    }
    unsigned long long keys=p, vals=p + n*(unsigned long long)c->rsz;
    if(vals + n*(unsigned long long)c->rsz > len) return 0;
    unsigned long long i; int got=0;
    for(i=0;i<n;i++){
        unsigned long long koff=bpl_obj_off(c, be_read(b+keys+i*(unsigned long long)c->rsz, c->rsz));
        if(!koff) continue;
        long long *dst=NULL;
        if(bpl_str_eq(c,koff,"Birth"))             dst=birth;
        else if(bpl_str_eq(c,koff,"LastModified")) dst=modi;
        else if(bpl_str_eq(c,koff,"Size"))         dst=size;
        else continue;
        unsigned long long voff=bpl_obj_off(c, be_read(b+vals+i*(unsigned long long)c->rsz, c->rsz));
        long long val;
        if(voff && bpl_int_at(c,voff,&val) && dst){ *dst=val; got++; }
    }
    return got;
}
/* The NSKeyedArchiver top object is the wrapper dict ($objects/$top/...), so we
   scan every object for the one dict that carries Birth/LastModified/Size -- the
   MBFile -- and read them from it. */
static int bplist_mbfile(const unsigned char *b, size_t len,
                         long long *birth, long long *modified, long long *size){
    if(!b || len<40 || memcmp(b,"bplist00",8)!=0) return 0;
    const unsigned char *T=b+len-32;
    bpl c; c.b=b; c.len=len; c.osz=T[6]; c.rsz=T[7];
    c.nobj=be_read(T+8,8); c.toff=be_read(T+24,8);
    if(c.osz<1||c.osz>8||c.rsz<1||c.rsz>8) return 0;
    if(c.toff + c.nobj*(unsigned long long)c.osz > len) return 0;
    unsigned long long idx;
    for(idx=0; idx<c.nobj; idx++){
        unsigned long long off=bpl_obj_off(&c, idx);
        if(off==0 || off>=len) continue;
        if((b[off]&0xF0)!=0xD0) continue;            /* dict marker */
        if(dict_extract(&c, off, birth, modified, size)>0) return 1;
    }
    return 0;
}

/* ================================ archive ================================ */

int man_is_manifest(const char *path){
    FILE *f=open_ro_utf8(path);
    if(!f) return 0;
    unsigned char hdr[16]={0}; size_t r=fread(hdr,1,16,f); fclose(f);
    if(r<16 || memcmp(hdr,"SQLite format 3\0",16)!=0) return 0;
    sqlite3 *db; if(sqlite3_open(path,&db)!=SQLITE_OK){ sqlite3_close(db); return 0; }
    sqlite3_stmt *st; int ok=0;
    if(sqlite3_prepare_v2(db,
        "SELECT fileID, domain, relativePath, flags FROM Files LIMIT 1",-1,&st,0)==SQLITE_OK){
        ok=1; sqlite3_finalize(st);
    }
    sqlite3_close(db);
    return ok;
}

/* --------------------------- directory dedup ------------------------------ */
/* With actual-path names, several domains now resolve into the same real subtree
   (/var/mobile is the union of HomeDomain, CameraRollDomain, MediaDomain,
   KeyboardDomain, ...), so identical directory paths recur across rows. Collapse
   duplicate DIRECTORY entries to one, preferring non-zero timestamps; keep all
   file entries (a genuine file/file path collision is unexpected, so log it).

   Sort by name so duplicates are adjacent, then compact in place. Moved/dropped
   source slots are NULLed so the surviving pointer lives in exactly one slot --
   man_close then frees each once, with no leak and no double-free. */
static int cmp_entry_name(const void *a, const void *b){
    const man_entry *x=(const man_entry*)a, *y=(const man_entry*)b;
    return strcmp(x->name?x->name:"", y->name?y->name:"");
}
static void man_dedup_dirs(man_archive *a){
    if(!a || a->count<2) return;
    qsort(a->items, a->count, sizeof(man_entry), cmp_entry_name);
    int w=0, i, merged=0;
    for(i=0;i<a->count;i++){
        if(w>0 && strcmp(a->items[i].name, a->items[w-1].name)==0){
            if(a->items[i].isdir && a->items[w-1].isdir){
                /* duplicate directory -> fold timestamps into the kept one, drop */
                if(a->items[w-1].ctime==0 && a->items[i].ctime>0) a->items[w-1].ctime=a->items[i].ctime;
                if(a->items[w-1].mtime==0 && a->items[i].mtime>0) a->items[w-1].mtime=a->items[i].mtime;
                free(a->items[i].name); free(a->items[i].src);
                a->items[i].name=NULL; a->items[i].src=NULL;
                merged++;
                continue;
            }
            man_log("man_dedup: path collision (non-dir kept): %s", a->items[i].name);
        }
        if(i!=w){
            a->items[w]=a->items[i];
            a->items[i].name=NULL; a->items[i].src=NULL;   /* moved: drop the alias */
        }
        w++;
    }
    a->count=w;
    man_log("man_dedup: merged %d duplicate directories, %d entries remain", merged, a->count);
}

man_archive* man_open(const char *path){
    man_log("man_open: path=%s", path ? path : "(null)");
    sqlite3 *db; int oc=sqlite3_open(path,&db);
    man_log("man_open: sqlite3_open rc=%d", oc);
    if(oc!=SQLITE_OK){ sqlite3_close(db); return NULL; }

    char root[4096]; backup_root_of(path, root, sizeof(root));
    man_log("man_open: backup root = %s", root);

    man_archive *a=(man_archive*)calloc(1,sizeof(man_archive));
    int cap=1024; a->items=(man_entry*)malloc(cap*sizeof(man_entry)); a->count=0;

    sqlite3_stmt *q=NULL;
    int pc=sqlite3_prepare_v2(db,
        "SELECT fileID, domain, relativePath, flags, file FROM Files ORDER BY domain, relativePath",
        -1,&q,0);
    man_log("man_open: Files query prepare rc=%d (0=OK)", pc);

    int n_file=0, n_dir=0, n_link=0, n_absent=0;
    while(q && sqlite3_step(q)==SQLITE_ROW){
        const char *fid =(const char*)sqlite3_column_text(q,0);
        const char *dom =(const char*)sqlite3_column_text(q,1);
        const char *rel =(const char*)sqlite3_column_text(q,2);
        int flags = (int)sqlite3_column_int64(q,3);
        const unsigned char *fblob=(const unsigned char*)sqlite3_column_blob(q,4);
        int fblen=sqlite3_column_bytes(q,4);
        if(!fid || strlen(fid)<2) continue;

        char name[2048]; build_name(dom, rel, name, sizeof(name));

        long long birth=0, modi=0, msz=0;
        bplist_mbfile(fblob,(size_t)fblen,&birth,&modi,&msz);
        long long mtime=(modi>0)?modi:0;
        long long ctime=(birth>0)?birth:mtime;
        long long size =(msz>0)?msz:0;

        char *src=NULL; int isdir=0;
        if(flags==2){
            isdir=1; size=0; n_dir++;
        } else if(flags==1){
            char bp[4096];
            if(blob_exists(root, fid, bp, sizeof(bp))){ src=strdup(bp); n_file++; }
            else n_absent++;
        } else {
            n_link++;                          /* symlink (flags=4): listed, no content */
        }

        if(a->count==cap){ cap*=2; a->items=(man_entry*)realloc(a->items,cap*sizeof(man_entry)); }
        a->items[a->count].name=strdup(name);
        a->items[a->count].src=src;
        a->items[a->count].size=size;
        a->items[a->count].ctime=ctime;
        a->items[a->count].mtime=mtime;
        a->items[a->count].isdir=isdir;
        a->count++;
    }
    if(q) sqlite3_finalize(q);
    sqlite3_close(db);
    man_dedup_dirs(a);   /* collapse the directory entries that several domains
                            now resolve into the same actual-path subtree */
    man_log("man_open: %d entries (files=%d dirs=%d links/other=%d absent-content=%d)",
        a->count, n_file, n_dir, n_link, n_absent);
    return a;
}

void man_close(man_archive *a){
    if(!a) return; int i;
    for(i=0;i<a->count;i++){ free(a->items[i].name); free(a->items[i].src); }
    free(a->items); free(a);
}

/* ================================= test ================================== */
#ifdef MANCORE_TEST_MAIN
int main(int argc,char **argv){
    if(argc<2){ fprintf(stderr,"usage: %s Manifest.db\n",argv[0]); return 2; }
    if(!man_is_manifest(argv[1])){ fprintf(stderr,"not a Manifest.db\n"); return 3; }
    man_archive *a=man_open(argv[1]); if(!a){ fprintf(stderr,"open failed\n"); return 4; }
    int i;
    for(i=0;i<a->count;i++){
        /* TYPE \t size \t mtime \t ctime \t hasSrc \t name */
        printf("%s\t%lld\t%lld\t%lld\t%d\t%s\n",
            a->items[i].isdir?"D":(a->items[i].src?"F":"-"),
            a->items[i].size, a->items[i].mtime, a->items[i].ctime,
            a->items[i].src?1:0, a->items[i].name);
    }
    fprintf(stderr,"%d entries\n", a->count);
    man_close(a);
    return 0;
}
#endif
